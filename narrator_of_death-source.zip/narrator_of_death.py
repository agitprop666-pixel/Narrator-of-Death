"""
Narrator of Death
Death's Head Software
A multi-format ebook/document narrator with neural TTS engines.
"""

from __future__ import annotations

# =============================================================================
# IMPORTS & CONSTANTS
# =============================================================================

import asyncio
import hashlib
import io
import logging
import os
import queue
import re
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import threading
import time
import wave
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import numpy as np
import sounddevice as sd

from PyQt6.QtCore import (
    QObject, QSettings, QSize, Qt, QThread, QTimer, pyqtSignal,
    Qt as QtCore
)
from PyQt6.QtGui import (
    QAction, QColor, QFont, QIcon, QKeySequence, QMouseEvent,
    QPainter, QPixmap, QTextCharFormat, QTextCursor,
)
from PyQt6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QDialog, QDialogButtonBox,
    QFileDialog, QFrame, QGridLayout, QGroupBox, QHBoxLayout, QLabel,
    QLineEdit, QListWidget, QListWidgetItem, QMainWindow, QMessageBox,
    QProgressBar, QPushButton, QScrollArea, QSlider, QSplashScreen,
    QSplitter, QStatusBar, QTabWidget, QTextEdit, QTreeWidget,
    QTreeWidgetItem, QVBoxLayout, QWidget, QInputDialog,
)

# ---------------------------------------------------------------------------
# App metadata
# ---------------------------------------------------------------------------
APP_NAME    = "Narrator of Death"
APP_SLUG    = "NarratorOfDeath"
ORG_NAME    = "Death's Head Software"
ORG_SLUG    = "DeathsHeadSoftware"
APP_VERSION = "1.0.0"
MAX_TABS    = 5

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
APPDATA_ROOT = Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming"))
APP_DATA_DIR = APPDATA_ROOT / ORG_SLUG / APP_SLUG
COVERS_DIR   = APP_DATA_DIR / "covers"
DB_PATH      = APP_DATA_DIR / "narrator.db"
LOG_PATH     = APP_DATA_DIR / "narrator.log"

APP_DATA_DIR.mkdir(parents=True, exist_ok=True)
COVERS_DIR.mkdir(parents=True, exist_ok=True)

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.FileHandler(LOG_PATH, encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)
log = logging.getLogger(APP_SLUG)

# ---------------------------------------------------------------------------
# ffmpeg
# ---------------------------------------------------------------------------
def _find_ffmpeg() -> str:
    if getattr(sys, "frozen", False):
        base = Path(sys.executable).parent
        for name in ("ffmpeg.exe", "ffmpeg"):
            p = base / name
            if p.exists():
                return str(p)
    return shutil.which("ffmpeg") or "ffmpeg"

FFMPEG_PATH = _find_ffmpeg()

def _run_subprocess(cmd: list, input: bytes = None, timeout: int = 120) -> subprocess.CompletedProcess:
    """Run a subprocess without flashing a console window on Windows."""
    kwargs = dict(
        capture_output=True,
        timeout=timeout,
    )
    if input is not None:
        kwargs['input'] = input
    if sys.platform == "win32":
        kwargs['creationflags'] = subprocess.CREATE_NO_WINDOW
    return subprocess.run(cmd, **kwargs)

# ---------------------------------------------------------------------------
# Theme — dark UI, light reader canvas
# ---------------------------------------------------------------------------
UI_BG        = "#1E1E1E"
UI_BG2       = "#2D2D2D"
UI_BG3       = "#3A3A3A"
DARK_RED     = "#8B0000"
ACCENT_RED   = "#C41E3A"
UI_TEXT      = "#E8E8E8"
UI_TEXT_DIM  = "#AAAAAA"
BORDER       = "#444444"
READER_BG    = "#FFFFF0"
READER_TEXT  = "#1A1A1A"
HIGHLIGHT_BG = "#FFD700"
HIGHLIGHT_FG = "#000000"
APP_FONT     = "Arial"


# =============================================================================
# DATABASE
# =============================================================================

class Database:
    def __init__(self, path: Path = DB_PATH):
        self.path = path
        self._conn = sqlite3.connect(str(path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._lock = threading.Lock()
        self._init_schema()

    def _init_schema(self):
        with self._lock:
            self._conn.executescript("""
                CREATE TABLE IF NOT EXISTS library (
                    id          INTEGER PRIMARY KEY AUTOINCREMENT,
                    file_path   TEXT UNIQUE NOT NULL,
                    title       TEXT,
                    author      TEXT,
                    cover_cache TEXT,
                    file_hash   TEXT,
                    date_added  TEXT DEFAULT (datetime('now')),
                    last_opened TEXT
                );
                CREATE TABLE IF NOT EXISTS positions (
                    file_path      TEXT PRIMARY KEY,
                    chapter_index  INTEGER DEFAULT 0,
                    sentence_index INTEGER DEFAULT 0,
                    updated        TEXT DEFAULT (datetime('now'))
                );
                CREATE TABLE IF NOT EXISTS bookmarks (
                    id             INTEGER PRIMARY KEY AUTOINCREMENT,
                    file_path      TEXT NOT NULL,
                    chapter_index  INTEGER NOT NULL,
                    sentence_index INTEGER NOT NULL,
                    label          TEXT DEFAULT '',
                    note           TEXT DEFAULT '',
                    created        TEXT DEFAULT (datetime('now'))
                );
            """)
            self._conn.commit()

    def upsert_library(self, file_path, title, author, cover_cache="", file_hash=""):
        with self._lock:
            self._conn.execute("""
                INSERT INTO library (file_path, title, author, cover_cache, file_hash, last_opened)
                VALUES (?, ?, ?, ?, ?, datetime('now'))
                ON CONFLICT(file_path) DO UPDATE SET
                    title=excluded.title, author=excluded.author,
                    cover_cache=excluded.cover_cache, file_hash=excluded.file_hash,
                    last_opened=datetime('now')
            """, (file_path, title, author, cover_cache, file_hash))
            self._conn.commit()

    def get_library(self):
        with self._lock:
            return self._conn.execute(
                "SELECT * FROM library ORDER BY last_opened DESC"
            ).fetchall()

    def remove_from_library(self, file_path):
        with self._lock:
            self._conn.execute("DELETE FROM library WHERE file_path=?", (file_path,))
            self._conn.execute("DELETE FROM positions WHERE file_path=?", (file_path,))
            self._conn.execute("DELETE FROM bookmarks WHERE file_path=?", (file_path,))
            self._conn.commit()

    def save_position(self, file_path, chapter, sentence):
        with self._lock:
            self._conn.execute("""
                INSERT INTO positions (file_path, chapter_index, sentence_index, updated)
                VALUES (?, ?, ?, datetime('now'))
                ON CONFLICT(file_path) DO UPDATE SET
                    chapter_index=excluded.chapter_index,
                    sentence_index=excluded.sentence_index,
                    updated=datetime('now')
            """, (file_path, chapter, sentence))
            self._conn.commit()

    def get_position(self, file_path):
        with self._lock:
            row = self._conn.execute(
                "SELECT chapter_index, sentence_index FROM positions WHERE file_path=?",
                (file_path,)
            ).fetchone()
            return (row["chapter_index"], row["sentence_index"]) if row else (0, 0)

    def add_bookmark(self, file_path, chapter, sentence, label="", note=""):
        with self._lock:
            cur = self._conn.execute("""
                INSERT INTO bookmarks (file_path, chapter_index, sentence_index, label, note)
                VALUES (?, ?, ?, ?, ?)
            """, (file_path, chapter, sentence, label, note))
            self._conn.commit()
            return cur.lastrowid

    def get_bookmarks(self, file_path):
        with self._lock:
            return self._conn.execute(
                "SELECT * FROM bookmarks WHERE file_path=? ORDER BY chapter_index, sentence_index",
                (file_path,)
            ).fetchall()

    def update_bookmark(self, bm_id, label, note):
        with self._lock:
            self._conn.execute(
                "UPDATE bookmarks SET label=?, note=? WHERE id=?", (label, note, bm_id)
            )
            self._conn.commit()

    def delete_bookmark(self, bm_id):
        with self._lock:
            self._conn.execute("DELETE FROM bookmarks WHERE id=?", (bm_id,))
            self._conn.commit()

    def close(self):
        self._conn.close()


# =============================================================================
# DATA STRUCTURES
# =============================================================================

@dataclass
class Chapter:
    index: int
    title: str
    sentences: list[str] = field(default_factory=list)
    raw_text: str = ""

@dataclass
class Book:
    file_path: str
    title: str
    author: str
    chapters: list[Chapter] = field(default_factory=list)
    cover_pixmap: Optional[QPixmap] = None
    file_hash: str = ""


# =============================================================================
# FILE PARSERS
# =============================================================================

def _file_hash(path: str) -> str:
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()

def _tokenize_sentences(text: str) -> list[str]:
    text = re.sub(r'\s+', ' ', text).strip()
    parts = re.split(r'(?<=[.!?])\s+(?=[A-Z"\'])', text)
    return [p.strip() for p in parts if p.strip()] or [text]

def _clean_text(text: str) -> str:
    text = re.sub(r'\s+', ' ', text)
    text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', text)
    return text.strip()

def _pixmap_from_bytes(data: bytes) -> Optional[QPixmap]:
    try:
        pm = QPixmap()
        pm.loadFromData(data)
        return pm if not pm.isNull() else None
    except Exception:
        return None


class EpubParser:
    def parse(self, file_path: str) -> Book:
        import ebooklib
        from ebooklib import epub
        from bs4 import BeautifulSoup
        book_obj = epub.read_epub(file_path, options={"ignore_ncx": True})
        title_meta  = book_obj.get_metadata('DC', 'title')
        author_meta = book_obj.get_metadata('DC', 'creator')
        title  = title_meta[0][0]  if title_meta  else Path(file_path).stem
        author = author_meta[0][0] if author_meta else "Unknown"
        chapters = []
        idx = 0
        for item_id, _ in book_obj.spine:
            item = book_obj.get_item_with_id(item_id)
            if item is None or item.get_type() != ebooklib.ITEM_DOCUMENT:
                continue
            soup = BeautifulSoup(item.get_content(), "html.parser")
            heading = soup.find(['h1','h2','h3'])
            ch_title = heading.get_text(strip=True) if heading else f"Chapter {idx+1}"
            raw = _clean_text(soup.get_text(separator=' '))
            if len(raw) < 30:
                continue
            chapters.append(Chapter(idx, ch_title, _tokenize_sentences(raw), raw))
            idx += 1
        cover_data = None
        for item in book_obj.get_items():
            if item.get_type() == ebooklib.ITEM_COVER or \
               (hasattr(item, 'file_name') and 'cover' in item.file_name.lower()):
                cover_data = item.get_content()
                break
        if not cover_data:
            for item in book_obj.get_items_of_type(ebooklib.ITEM_IMAGE):
                cover_data = item.get_content()
                break
        book = Book(file_path, title, author, chapters, file_hash=_file_hash(file_path))
        if cover_data:
            book.cover_pixmap = _pixmap_from_bytes(cover_data)
        return book


class PdfParser:
    def parse(self, file_path: str) -> Book:
        import pdfplumber
        title  = Path(file_path).stem
        author = "Unknown"
        chapters = []
        with pdfplumber.open(file_path) as pdf:
            if pdf.metadata:
                title  = pdf.metadata.get("Title",  title)  or title
                author = pdf.metadata.get("Author", author) or author
            pages = pdf.pages
            chunk_size = 20
            for ci, start in enumerate(range(0, len(pages), chunk_size)):
                chunk = pages[start:start + chunk_size]
                raw = " ".join(_clean_text(p.extract_text() or "") for p in chunk)
                if len(raw) < 30:
                    continue
                ch_title = f"Pages {start+1}-{min(start+chunk_size, len(pages))}"
                chapters.append(Chapter(ci, ch_title, _tokenize_sentences(raw), raw))
        book = Book(file_path, title, author, chapters, file_hash=_file_hash(file_path))
        try:
            with pdfplumber.open(file_path) as pdf:
                if pdf.pages:
                    img = pdf.pages[0].to_image(resolution=100).original
                    buf = tempfile.NamedTemporaryFile(suffix=".png", delete=False)
                    img.save(buf.name)
                    book.cover_pixmap = QPixmap(buf.name)
                    buf.close()
                    os.unlink(buf.name)
        except Exception:
            pass
        return book


class TxtParser:
    def parse(self, file_path: str) -> Book:
        with open(file_path, encoding="utf-8", errors="replace") as f:
            raw = f.read()
        title = Path(file_path).stem
        parts = re.split(r'\n{3,}', raw)
        chapters = []
        for ci, part in enumerate(parts):
            part = _clean_text(part)
            if len(part) < 30:
                continue
            chapters.append(Chapter(ci, f"Section {ci+1}", _tokenize_sentences(part), part))
        if not chapters and raw.strip():
            chapters.append(Chapter(0, title, _tokenize_sentences(_clean_text(raw)), raw))
        return Book(file_path, title, "Unknown", chapters, file_hash=_file_hash(file_path))


class DocxParser:
    def parse(self, file_path: str) -> Book:
        from docx import Document
        doc = Document(file_path)
        title = Path(file_path).stem
        author = "Unknown"
        try:
            props = doc.core_properties
            title  = props.title  or title
            author = props.author or author
        except Exception:
            pass
        chapters = []
        current_title = "Chapter 1"
        current_paras: list[str] = []
        ci = 0
        def _flush():
            nonlocal ci
            raw = _clean_text(" ".join(current_paras))
            if len(raw) > 30:
                chapters.append(Chapter(ci, current_title, _tokenize_sentences(raw), raw))
                ci += 1
        for para in doc.paragraphs:
            # Guard against paragraphs with no style or None style name
            try:
                style_name = para.style.name if para.style else ""
            except Exception:
                style_name = ""
            if style_name.startswith("Heading"):
                if current_paras:
                    _flush()
                    current_paras.clear()
                current_title = para.text.strip() or current_title
            elif para.text.strip():
                current_paras.append(para.text.strip())
        if current_paras:
            _flush()
        return Book(file_path, title, author, chapters, file_hash=_file_hash(file_path))


class MobiParser:
    def parse(self, file_path: str) -> Book:
        try:
            return self._parse_mobi_lib(file_path)
        except Exception as e:
            log.warning(f"mobi library failed ({e}), trying Calibre")
            return self._parse_calibre(file_path)

    def _parse_mobi_lib(self, file_path: str) -> Book:
        import mobi
        from bs4 import BeautifulSoup
        temp_dir = tempfile.mkdtemp()
        try:
            _, output_dir = mobi.extract(file_path)
            html_files = sorted(
                list(Path(output_dir).rglob("*.html")) +
                list(Path(output_dir).rglob("*.htm"))
            )
            if not html_files:
                raise RuntimeError("No HTML in MOBI extraction.")
            chapters = []
            for ci, hf in enumerate(html_files):
                soup = BeautifulSoup(hf.read_text(encoding="utf-8", errors="replace"), "html.parser")
                heading = soup.find(['h1','h2','h3'])
                ch_title = heading.get_text(strip=True) if heading else f"Chapter {ci+1}"
                raw = _clean_text(soup.get_text(separator=' '))
                if len(raw) < 30:
                    continue
                chapters.append(Chapter(ci, ch_title, _tokenize_sentences(raw), raw))
            return Book(file_path, Path(file_path).stem, "Unknown", chapters,
                        file_hash=_file_hash(file_path))
        finally:
            shutil.rmtree(temp_dir, ignore_errors=True)

    def _parse_calibre(self, file_path: str) -> Book:
        calibre = shutil.which("ebook-convert")
        if not calibre:
            raise RuntimeError("Calibre not found.")
        temp_dir = tempfile.mkdtemp()
        try:
            out_epub = str(Path(temp_dir) / "converted.epub")
            result = _run_subprocess(
                [calibre, file_path, out_epub],
                timeout=120
            )
            if result.returncode != 0:
                raise RuntimeError(f"Calibre: {result.stderr.decode()}")
            return EpubParser().parse(out_epub)
        finally:
            shutil.rmtree(temp_dir, ignore_errors=True)


class HtmlParser:
    def parse(self, file_path: str) -> Book:
        from bs4 import BeautifulSoup
        with open(file_path, encoding="utf-8", errors="replace") as f:
            soup = BeautifulSoup(f.read(), "html.parser")
        title = (soup.title.string if soup.title else None) or Path(file_path).stem
        raw = _clean_text(soup.get_text(separator=' '))
        sentences = _tokenize_sentences(raw)
        chapters = []
        chunk = 100
        for ci, start in enumerate(range(0, len(sentences), chunk)):
            sl = sentences[start:start+chunk]
            chapters.append(Chapter(ci, f"Section {ci+1}", sl, " ".join(sl)))
        return Book(file_path, title, "Unknown", chapters, file_hash=_file_hash(file_path))


PARSERS = {
    ".epub": EpubParser, ".pdf": PdfParser,
    ".txt": TxtParser, ".md": TxtParser, ".rst": TxtParser,
    ".docx": DocxParser,
    ".mobi": MobiParser, ".azw": MobiParser, ".azw3": MobiParser,
    ".html": HtmlParser, ".htm": HtmlParser,
}

def parse_book(file_path: str) -> Book:
    ext = Path(file_path).suffix.lower()
    cls = PARSERS.get(ext)
    if cls is None:
        raise ValueError(f"Unsupported format: {ext}")
    return cls().parse(file_path)

def supported_filter() -> str:
    return (
        "All Supported (*.epub *.pdf *.txt *.md *.rst *.docx *.mobi *.azw *.azw3 *.html *.htm);;"
        "EPUB (*.epub);;PDF (*.pdf);;Text (*.txt *.md *.rst);;"
        "Word (*.docx);;Kindle (*.mobi *.azw *.azw3);;HTML (*.html *.htm)"
    )


# ---------------------------------------------------------------------------
# Cover art
# ---------------------------------------------------------------------------
def _skull_placeholder(title: str, size: QSize = QSize(160, 220)) -> QPixmap:
    pm = QPixmap(size)
    pm.fill(QColor(20, 20, 20))
    painter = QPainter(pm)
    skull = ["  .---.  ", " (o   o) ", "  \\ ^ /  ", "  |||||  "]
    y = 40
    painter.setPen(QColor(200, 200, 200))
    painter.setFont(QFont(APP_FONT, 8))
    for line in skull:
        painter.drawText(0, y, size.width(), 20, Qt.AlignmentFlag.AlignCenter, line)
        y += 18
    painter.setPen(QColor(180, 30, 30))
    painter.setFont(QFont(APP_FONT, 8, QFont.Weight.Bold))
    t = title[:18] + "..." if len(title) > 18 else title
    painter.drawText(0, size.height()-50, size.width(), 40,
                     Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignTop, t)
    painter.end()
    return pm

def get_or_create_cover(book, size: QSize = QSize(160, 220)) -> QPixmap:
    cache_path = COVERS_DIR / f"{book.file_hash}.png"
    if cache_path.exists():
        pm = QPixmap(str(cache_path))
        if not pm.isNull():
            return pm.scaled(size, Qt.AspectRatioMode.KeepAspectRatio,
                             Qt.TransformationMode.SmoothTransformation)
    if hasattr(book, 'cover_pixmap') and book.cover_pixmap and not book.cover_pixmap.isNull():
        scaled = book.cover_pixmap.scaled(size, Qt.AspectRatioMode.KeepAspectRatio,
                                          Qt.TransformationMode.SmoothTransformation)
        scaled.save(str(cache_path))
        return scaled
    pm = _skull_placeholder(book.title if hasattr(book, 'title') else str(book), size)
    if book.file_hash:
        pm.save(str(cache_path))
    return pm


# =============================================================================
# TTS ENGINES (edge-tts + pyttsx3 only)
# =============================================================================

class TTSEngine:
    name: str = "base"
    def is_available(self) -> bool: return False
    def get_voices(self) -> list[dict]: return []
    def synthesize(self, text: str, voice_id: str,
                   speed: float = 1.0, pitch: float = 0.0) -> np.ndarray:
        raise NotImplementedError
    @property
    def sample_rate(self) -> int: return 22050
    def preview(self, voice_id: str, speed: float = 1.0) -> np.ndarray:
        return self.synthesize("Hello, this is a voice preview from Narrator of Death.", voice_id, speed)


class Pyttsx3Engine(TTSEngine):
    name = "pyttsx3 (Offline)"

    def is_available(self) -> bool:
        try:
            import pyttsx3; return True
        except ImportError:
            return False

    def get_voices(self) -> list[dict]:
        try:
            import pyttsx3
            engine = pyttsx3.init()
            voices = engine.getProperty("voices") or []
            result = [{"id": v.id, "name": v.name, "language": ""} for v in voices]
            engine.stop()
            return result
        except Exception:
            return [{"id": "default", "name": "Default Voice", "language": "en"}]

    def synthesize(self, text: str, voice_id: str,
                   speed: float = 1.0, pitch: float = 0.0) -> np.ndarray:
        import pyttsx3
        tmp = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
        tmp.close()
        try:
            engine = pyttsx3.init()
            if voice_id and voice_id != "default":
                engine.setProperty("voice", voice_id)
            rate = engine.getProperty("rate")
            engine.setProperty("rate", int(rate * speed))
            engine.save_to_file(text, tmp.name)
            engine.runAndWait()
            engine.stop()
            with wave.open(tmp.name, "rb") as wf:
                frames = wf.readframes(wf.getnframes())
                return np.frombuffer(frames, dtype=np.int16).astype(np.float32) / 32768.0
        finally:
            try: os.unlink(tmp.name)
            except: pass

    @property
    def sample_rate(self) -> int: return 22050


class EdgeTTSEngine(TTSEngine):
    name = "edge-tts (Online)"
    _voices_cache: list[dict] = []
    _sr: int = 24000

    def is_available(self) -> bool:
        try:
            import edge_tts; return True
        except ImportError:
            return False

    def get_voices(self) -> list[dict]:
        if self._voices_cache:
            return self._voices_cache
        try:
            import edge_tts
            async def _fetch():
                return await edge_tts.list_voices()
            voices = asyncio.run(_fetch())
            self._voices_cache = [
                {"id": v["ShortName"], "name": v["FriendlyName"], "language": v["Locale"]}
                for v in voices
            ]
            return self._voices_cache
        except Exception as e:
            log.warning(f"edge-tts voice list failed: {e}")
            return [{"id": "en-US-AriaNeural", "name": "Aria (US English)", "language": "en-US"}]

    def synthesize(self, text: str, voice_id: str,
                   speed: float = 1.0, pitch: float = 0.0) -> np.ndarray:
        import edge_tts
        if not voice_id:
            voice_id = "en-US-AriaNeural"
        rate_str  = f"+{int((speed-1)*100)}%" if speed >= 1 else f"-{int((1-speed)*100)}%"
        pitch_str = f"+{int(pitch)}Hz" if pitch >= 0 else f"{int(pitch)}Hz"

        async def _synth():
            comm = edge_tts.Communicate(text, voice_id, rate=rate_str, pitch=pitch_str)
            chunks = []
            async for chunk in comm.stream():
                if chunk["type"] == "audio":
                    chunks.append(chunk["data"])
            return b"".join(chunks)

        mp3_data = asyncio.run(_synth())
        if not mp3_data:
            return np.zeros(1000, dtype=np.float32)

        # Convert mp3 -> wav via ffmpeg
        proc = _run_subprocess(
            [FFMPEG_PATH, "-y", "-i", "pipe:0",
             "-ar", "24000", "-ac", "1", "-f", "wav", "pipe:1"],
            input=mp3_data, timeout=30
        )
        if proc.returncode != 0:
            raise RuntimeError(f"ffmpeg: {proc.stderr.decode()[:200]}")

        with wave.open(io.BytesIO(proc.stdout), "rb") as wf:
            self._sr = wf.getframerate()
            frames = wf.readframes(wf.getnframes())
            return np.frombuffer(frames, dtype=np.int16).astype(np.float32) / 32768.0

    @property
    def sample_rate(self) -> int:
        return self._sr


# =============================================================================
# TTS MANAGER — pipelined synthesis + playback
# =============================================================================

class TTSManager(QObject):
    """
    Runs synthesis in a producer thread and playback in a consumer thread,
    overlapping them to eliminate the gap between sentences.
    All signals emitted via queued connection to avoid UI freeze.
    """
    sentence_started  = pyqtSignal(int)
    sentence_finished = pyqtSignal(int)
    playback_finished = pyqtSignal()
    error_occurred    = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        self._engines: dict[str, TTSEngine] = {}
        self._current_engine: Optional[TTSEngine] = None
        self._voice_id = ""
        self._speed    = 1.0
        self._pitch    = 0.0
        self._volume   = 1.0

        self._sentences: list[str] = []
        self._start_idx = 0
        self._stop_flag = threading.Event()
        self._pause_flag = threading.Event()
        self._pause_flag.set()   # not paused initially

        self._synth_thread: Optional[threading.Thread] = None
        self._play_thread:  Optional[threading.Thread] = None
        # Queue holds (sentence_idx, audio_array, sample_rate)
        self._audio_q: queue.Queue = queue.Queue(maxsize=3)

        self._init_engines()

    def _init_engines(self):
        for cls in [EdgeTTSEngine, Pyttsx3Engine]:
            engine = cls()
            if engine.is_available():
                self._engines[engine.name] = engine
                log.info(f"TTS engine available: {engine.name}")
        if self._engines:
            self._current_engine = next(iter(self._engines.values()))

    def available_engines(self) -> list[str]: return list(self._engines.keys())
    def set_engine(self, name: str):
        if e := self._engines.get(name):
            self._current_engine = e
    def set_voice(self, v: str):   self._voice_id = v
    def set_speed(self, s: float): self._speed = max(0.5, min(3.0, s))
    def set_pitch(self, p: float): self._pitch = p
    def set_volume(self, v: float): self._volume = max(0.0, min(1.0, v))
    def get_voices(self) -> list[dict]:
        return self._current_engine.get_voices() if self._current_engine else []

    def play(self, sentences: list[str], start_idx: int = 0):
        self.stop()
        # Give previous daemon threads a moment to notice the stop flag
        # before we clear it. Non-blocking — just yields the GIL briefly.
        time.sleep(0.05)
        self._sentences  = sentences
        self._start_idx  = start_idx
        self._stop_flag.clear()
        self._pause_flag.set()
        # Fresh queue
        self._audio_q = queue.Queue(maxsize=2)
        self._synth_thread = threading.Thread(target=self._synth_run, daemon=True,
                                               name="tts-synth")
        self._play_thread  = threading.Thread(target=self._play_run,  daemon=True,
                                               name="tts-play")
        self._synth_thread.start()
        self._play_thread.start()

    def pause(self):  self._pause_flag.clear()
    def resume(self): self._pause_flag.set()

    def stop(self):
        self._stop_flag.set()
        self._pause_flag.set()   # unblock if paused
        # Drain queue to unblock any blocked put() in synth thread
        for _ in range(self._audio_q.maxsize + 2):
            try: self._audio_q.put_nowait(None)
            except: break
        # Do NOT join here — never block the UI thread.
        # Threads are daemon threads; they will exit on their own.
        self._synth_thread = None
        self._play_thread  = None
        # Drain remaining items
        while not self._audio_q.empty():
            try: self._audio_q.get_nowait()
            except: pass

    # -- Producer: synthesize sentences and push to queue --
    def _synth_run(self):
        engine = self._current_engine
        if not engine:
            self.error_occurred.emit("No TTS engine available.")
            return
        try:
            for idx in range(self._start_idx, len(self._sentences)):
                if self._stop_flag.is_set():
                    break
                self._pause_flag.wait()
                if self._stop_flag.is_set():
                    break
                sentence = self._sentences[idx].strip()
                if not sentence:
                    continue
                try:
                    audio = engine.synthesize(sentence, self._voice_id, self._speed, self._pitch)
                    audio = (audio * self._volume).clip(-1.0, 1.0)
                    self._audio_q.put((idx, audio, engine.sample_rate))
                except Exception as e:
                    log.error(f"Synthesis error sentence {idx}: {e}")
                    self.error_occurred.emit(str(e))
                    break
        finally:
            self._audio_q.put(None)   # sentinel

    # -- Consumer: play audio from queue --
    def _play_run(self):
        while not self._stop_flag.is_set():
            try:
                item = self._audio_q.get(timeout=0.1)
            except queue.Empty:
                continue
            if item is None:
                break
            idx, audio, sr = item
            self.sentence_started.emit(idx)
            self._play_audio(audio, sr)
            self.sentence_finished.emit(idx)
        if not self._stop_flag.is_set():
            self.playback_finished.emit()

    def _play_audio(self, samples: np.ndarray, sr: int):
        if samples.ndim == 1:
            samples = samples.reshape(-1, 1)
        done = threading.Event()

        def _cb(outdata, frames, time_info, status):
            if self._stop_flag.is_set():
                outdata[:] = 0
                raise sd.CallbackStop()
            # Handle pause: spin-wait here (keeps stream open, avoids glitch)
            if not self._pause_flag.is_set():
                outdata[:] = 0
                return
            remaining = len(samples) - _cb.pos
            if remaining <= 0:
                outdata[:] = 0
                raise sd.CallbackStop()
            n = min(frames, remaining)
            outdata[:n] = samples[_cb.pos:_cb.pos+n]
            if n < frames:
                outdata[n:] = 0
            _cb.pos += n

        _cb.pos = 0
        try:
            with sd.OutputStream(samplerate=sr, channels=1, dtype="float32",
                                  callback=_cb, finished_callback=done.set,
                                  blocksize=2048):
                done.wait()
        except Exception as e:
            log.warning(f"Playback error: {e}")

    def preview_voice(self, voice_id: str):
        def _do():
            try:
                engine = self._current_engine
                if not engine:
                    return
                audio = engine.preview(voice_id)
                if audio is None or len(audio) == 0:
                    return
                samples = audio.reshape(-1, 1) if audio.ndim == 1 else audio
                done = threading.Event()
                pos = [0]
                def _cb(outdata, frames, time_info, status):
                    remaining = len(samples) - pos[0]
                    if remaining <= 0:
                        outdata[:] = 0
                        raise sd.CallbackStop()
                    n = min(frames, remaining)
                    outdata[:n] = samples[pos[0]:pos[0]+n]
                    if n < frames:
                        outdata[n:] = 0
                    pos[0] += n
                with sd.OutputStream(samplerate=engine.sample_rate, channels=1,
                                     dtype="float32", callback=_cb,
                                     finished_callback=done.set, blocksize=2048):
                    done.wait()
            except Exception as e:
                log.warning(f"Preview failed: {e}")
        threading.Thread(target=_do, daemon=True).start()


# =============================================================================
# AUDIO EXPORT
# =============================================================================

class ExportWorker(QThread):
    progress = pyqtSignal(int, int, str)
    finished = pyqtSignal(str)
    error    = pyqtSignal(str)

    def __init__(self, book: Book, chapter_indices: list[int],
                 output_dir: str, engine: TTSEngine,
                 voice_id: str, speed: float, volume: float,
                 stitch_m4b: bool = False):
        super().__init__()
        self.book            = book
        self.chapter_indices = chapter_indices
        self.output_dir      = Path(output_dir)
        self.engine          = engine
        self.voice_id        = voice_id
        self.speed           = speed
        self.volume          = volume
        self.stitch_m4b      = stitch_m4b
        self._cancelled      = False

    def cancel(self): self._cancelled = True

    def run(self):
        try:
            self.output_dir.mkdir(parents=True, exist_ok=True)
            mp3_files = []
            total = len(self.chapter_indices)

            for n, ci in enumerate(self.chapter_indices):
                if self._cancelled:
                    break
                chapter = self.book.chapters[ci]
                self.progress.emit(n, total, f"Exporting: {chapter.title}")

                all_samples = []
                sr = self.engine.sample_rate
                for sentence in chapter.sentences:
                    if self._cancelled:
                        break
                    if not sentence.strip():
                        continue
                    try:
                        audio = self.engine.synthesize(sentence, self.voice_id, self.speed)
                        sr    = self.engine.sample_rate   # update after synth (edge-tts sets it)
                        all_samples.append((audio * self.volume).clip(-1.0, 1.0))
                        all_samples.append(np.zeros(int(sr * 0.15), dtype=np.float32))
                    except Exception as e:
                        log.warning(f"Export synth error: {e}")

                if not all_samples or self._cancelled:
                    continue

                combined = np.concatenate(all_samples).clip(-1.0, 1.0)

                # WAV buffer
                wav_buf = io.BytesIO()
                with wave.open(wav_buf, "wb") as wf:
                    wf.setnchannels(1)
                    wf.setsampwidth(2)
                    wf.setframerate(sr)
                    wf.writeframes((combined * 32767).astype(np.int16).tobytes())
                wav_buf.seek(0)

                safe = re.sub(r'[^\w\s-]', '', chapter.title)[:50].strip()
                safe = re.sub(r'\s+', '_', safe)
                mp3_path = self.output_dir / f"{ci+1:03d}_{safe}.mp3"

                proc = _run_subprocess(
                    [FFMPEG_PATH, "-y",
                     "-f", "wav", "-i", "pipe:0",
                     "-codec:a", "libmp3lame", "-q:a", "4",
                     str(mp3_path)],
                    input=wav_buf.read(),
                    timeout=300
                )
                if proc.returncode == 0:
                    mp3_files.append(str(mp3_path))
                    log.info(f"Exported: {mp3_path}")
                else:
                    err = proc.stderr.decode(errors='replace')
                    log.error(f"MP3 export failed ch {ci}: {err}")
                    self.error.emit(f"ffmpeg failed on chapter {ci+1}:\n{err[:300]}")
                    return

            if self.stitch_m4b and mp3_files and not self._cancelled:
                self.progress.emit(total, total, "Stitching M4B...")
                self._stitch_m4b(mp3_files)

            self.finished.emit(str(self.output_dir))

        except Exception as e:
            log.error(f"Export error: {e}", exc_info=True)
            self.error.emit(str(e))

    def _stitch_m4b(self, mp3_files: list[str]):
        try:
            list_file = self.output_dir / "_filelist.txt"
            with open(list_file, "w", encoding="utf-8") as f:
                for p in mp3_files:
                    # ffmpeg concat requires forward slashes
                    f.write(f"file '{p.replace(chr(92), '/')}'\n")
            safe_title = re.sub(r'[^\w]', '_', self.book.title)
            out_m4b = self.output_dir / f"{safe_title}.m4b"
            proc = _run_subprocess(
                [FFMPEG_PATH, "-y", "-f", "concat", "-safe", "0",
                 "-i", str(list_file), "-c:a", "aac", "-b:a", "64k",
                 str(out_m4b)],
                timeout=600
            )
            list_file.unlink(missing_ok=True)
            if proc.returncode != 0:
                log.error(f"M4B stitch failed: {proc.stderr.decode(errors='replace')}")
        except Exception as e:
            log.error(f"M4B stitch error: {e}")


# =============================================================================
# SPLASH SCREEN
# =============================================================================

def create_splash() -> Optional[QSplashScreen]:
    try:
        splash_path = Path(__file__).parent / "splash.png"
        if splash_path.exists():
            pixmap = QPixmap(str(splash_path))
            if pixmap.isNull():
                pixmap = QPixmap(800, 600)
                pixmap.fill(QColor(20, 20, 20))
            if pixmap.width() != 800 or pixmap.height() != 600:
                pixmap = pixmap.scaled(800, 600,
                                       Qt.AspectRatioMode.KeepAspectRatio,
                                       Qt.TransformationMode.SmoothTransformation)
        else:
            pixmap = QPixmap(800, 600)
            pixmap.fill(QColor(20, 20, 20))
        painter = QPainter(pixmap)
        painter.setPen(QColor(255, 255, 255))
        painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
        tr = pixmap.rect(); tr.setTop(40); tr.setBottom(100)
        painter.drawText(tr, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, APP_NAME)
        painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
        fr = pixmap.rect(); fr.setTop(pixmap.height() - 60); fr.setBottom(pixmap.height() - 20)
        painter.drawText(fr, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, ORG_NAME)
        painter.end()
        return QSplashScreen(pixmap, Qt.WindowType.WindowStaysOnTopHint)
    except Exception as e:
        log.error(f"Splash error: {e}")
        return None


# =============================================================================
# DARK THEME STYLESHEET
# =============================================================================

def dark_stylesheet() -> str:
    return f"""
        QWidget {{
            background-color: {UI_BG};
            color: {UI_TEXT};
            font-family: {APP_FONT};
            font-size: 13px;
        }}
        QMainWindow {{ background-color: {UI_BG}; }}
        QMenuBar {{
            background-color: {DARK_RED};
            color: white;
            font-family: {APP_FONT};
        }}
        QMenuBar::item:selected {{ background-color: {ACCENT_RED}; }}
        QMenu {{
            background-color: {UI_BG2};
            color: {UI_TEXT};
            border: 1px solid {BORDER};
        }}
        QMenu::item:selected {{ background-color: {ACCENT_RED}; color: white; }}
        QTabWidget::pane {{ border: 1px solid {BORDER}; background: {UI_BG2}; }}
        QTabBar::tab {{
            background: {UI_BG3};
            color: {UI_TEXT_DIM};
            padding: 6px 16px;
            border-top-left-radius: 4px;
            border-top-right-radius: 4px;
            margin-right: 2px;
            font-family: {APP_FONT};
        }}
        QTabBar::tab:selected {{ background: {DARK_RED}; color: white; }}
        QTabBar::tab:hover {{ background: {UI_BG2}; color: {UI_TEXT}; }}
        QScrollBar:vertical {{
            background: {UI_BG2}; width: 10px; border: none;
        }}
        QScrollBar::handle:vertical {{
            background: {UI_BG3}; border-radius: 5px; min-height: 20px;
        }}
        QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
        QScrollBar:horizontal {{
            background: {UI_BG2}; height: 10px; border: none;
        }}
        QScrollBar::handle:horizontal {{
            background: {UI_BG3}; border-radius: 5px; min-width: 20px;
        }}
        QStatusBar {{
            background: {UI_BG2};
            color: {UI_TEXT_DIM};
            font-family: {APP_FONT};
            font-size: 11px;
        }}
        QGroupBox {{
            border: 1px solid {BORDER};
            border-radius: 4px;
            margin-top: 8px;
            color: {UI_TEXT};
            font-family: {APP_FONT};
        }}
        QGroupBox::title {{
            subcontrol-origin: margin;
            left: 8px;
            padding: 0 4px;
            color: {ACCENT_RED};
        }}
        QPushButton {{
            background: {UI_BG3};
            color: {UI_TEXT};
            border: 1px solid {BORDER};
            border-radius: 4px;
            padding: 5px 12px;
            font-family: {APP_FONT};
        }}
        QPushButton:hover {{ background: {DARK_RED}; color: white; border-color: {DARK_RED}; }}
        QPushButton:pressed {{ background: {ACCENT_RED}; }}
        QPushButton:disabled {{ background: {UI_BG2}; color: {BORDER}; }}
        QComboBox {{
            background: {UI_BG2};
            color: {UI_TEXT};
            border: 1px solid {BORDER};
            border-radius: 4px;
            padding: 4px 8px;
        }}
        QComboBox QAbstractItemView {{
            background: {UI_BG2};
            color: {UI_TEXT};
            selection-background-color: {DARK_RED};
        }}
        QLineEdit {{
            background: {UI_BG2};
            color: {UI_TEXT};
            border: 1px solid {BORDER};
            border-radius: 4px;
            padding: 4px 8px;
        }}
        QSlider::groove:horizontal {{
            background: {UI_BG3};
            height: 4px;
            border-radius: 2px;
        }}
        QSlider::handle:horizontal {{
            background: {ACCENT_RED};
            width: 14px; height: 14px;
            border-radius: 7px;
            margin: -5px 0;
        }}
        QSlider::sub-page:horizontal {{ background: {DARK_RED}; border-radius: 2px; }}
        QTreeWidget {{
            background: {UI_BG2};
            color: {UI_TEXT};
            border: 1px solid {BORDER};
            alternate-background-color: {UI_BG3};
        }}
        QTreeWidget::item:selected {{ background: {DARK_RED}; color: white; }}
        QListWidget {{
            background: {UI_BG2};
            color: {UI_TEXT};
            border: 1px solid {BORDER};
        }}
        QListWidget::item:selected {{ background: {DARK_RED}; color: white; }}
        QProgressBar {{
            background: {UI_BG2};
            border: 1px solid {BORDER};
            border-radius: 4px;
            text-align: center;
            color: {UI_TEXT};
        }}
        QProgressBar::chunk {{ background: {DARK_RED}; border-radius: 3px; }}
        QSplitter::handle {{ background: {BORDER}; }}
        QDialog {{ background: {UI_BG}; }}
        QCheckBox {{ color: {UI_TEXT}; }}
        QCheckBox::indicator {{
            width: 14px; height: 14px;
            background: {UI_BG2};
            border: 1px solid {BORDER};
            border-radius: 3px;
        }}
        QCheckBox::indicator:checked {{ background: {DARK_RED}; }}
        QLabel {{ color: {UI_TEXT}; background: transparent; }}
        QFrame {{ background: {UI_BG}; }}
    """


# =============================================================================
# SETTINGS DIALOG
# =============================================================================

class SettingsDialog(QDialog):
    def __init__(self, tts: TTSManager, parent=None):
        super().__init__(parent)
        self.tts = tts
        self.setWindowTitle("Settings")
        self.setMinimumWidth(480)
        self._build_ui()
        self._load_settings()

    def _build_ui(self):
        layout = QVBoxLayout(self)

        grp_engine = QGroupBox("TTS Engine")
        gl = QVBoxLayout(grp_engine)
        self.engine_combo = QComboBox()
        self.engine_combo.addItems(self.tts.available_engines())
        self.engine_combo.currentTextChanged.connect(self._on_engine_changed)
        gl.addWidget(QLabel("Engine:"))
        gl.addWidget(self.engine_combo)
        layout.addWidget(grp_engine)

        grp_voice = QGroupBox("Voice")
        vl = QVBoxLayout(grp_voice)
        self.voice_combo = QComboBox()
        self.voice_combo.setMaxVisibleItems(15)
        preview_btn = QPushButton("Preview Voice")
        preview_btn.clicked.connect(self._preview_voice)
        vl.addWidget(QLabel("Voice:"))
        vl.addWidget(self.voice_combo)
        vl.addWidget(preview_btn)
        layout.addWidget(grp_voice)

        grp_pb = QGroupBox("Playback")
        pl = QVBoxLayout(grp_pb)
        pl.addWidget(QLabel("Speed (0.5x - 3.0x):"))
        row = QHBoxLayout()
        self.speed_slider = QSlider(Qt.Orientation.Horizontal)
        self.speed_slider.setRange(50, 300)
        self.speed_slider.setValue(100)
        self.speed_label = QLabel("1.0x")
        self.speed_slider.valueChanged.connect(lambda v: self.speed_label.setText(f"{v/100:.1f}x"))
        row.addWidget(self.speed_slider)
        row.addWidget(self.speed_label)
        pl.addLayout(row)
        pl.addWidget(QLabel("Volume:"))
        row2 = QHBoxLayout()
        self.vol_slider = QSlider(Qt.Orientation.Horizontal)
        self.vol_slider.setRange(0, 100)
        self.vol_slider.setValue(100)
        self.vol_label = QLabel("100%")
        self.vol_slider.valueChanged.connect(lambda v: self.vol_label.setText(f"{v}%"))
        row2.addWidget(self.vol_slider)
        row2.addWidget(self.vol_label)
        pl.addLayout(row2)
        layout.addWidget(grp_pb)

        grp_font = QGroupBox("Reader Font")
        fl = QVBoxLayout(grp_font)
        self.font_combo = QComboBox()
        self.font_combo.addItems(["Georgia", "Times New Roman", "Palatino Linotype",
                                   "Arial", "Verdana", "Courier New"])
        fl.addWidget(QLabel("Font Family:"))
        fl.addWidget(self.font_combo)
        layout.addWidget(grp_font)

        grp_exp = QGroupBox("Export")
        el = QVBoxLayout(grp_exp)
        self.export_dir_edit = QLineEdit()
        browse_btn = QPushButton("Browse...")
        browse_btn.clicked.connect(self._browse_export)
        row3 = QHBoxLayout()
        row3.addWidget(self.export_dir_edit)
        row3.addWidget(browse_btn)
        el.addWidget(QLabel("Default Export Directory:"))
        el.addLayout(row3)
        layout.addWidget(grp_exp)

        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        btns.accepted.connect(self._save_and_accept)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)

    def _load_settings(self):
        s = QSettings(ORG_SLUG, APP_SLUG)
        engine_name = s.value("tts/engine", "")
        idx = self.engine_combo.findText(engine_name)
        if idx >= 0:
            self.engine_combo.setCurrentIndex(idx)
        self._on_engine_changed(self.engine_combo.currentText())
        voice_id = s.value("tts/voice", "")
        vi = self.voice_combo.findData(voice_id)
        if vi >= 0:
            self.voice_combo.setCurrentIndex(vi)
        self.speed_slider.setValue(int(float(s.value("tts/speed", 1.0)) * 100))
        self.vol_slider.setValue(int(float(s.value("tts/volume", 1.0)) * 100))
        self.font_combo.setCurrentText(s.value("reader/font", "Georgia"))
        self.export_dir_edit.setText(s.value("export/dir",
            str(Path.home() / "Music" / "NarratorOfDeath")))

    def _on_engine_changed(self, name: str):
        self.tts.set_engine(name)
        self.voice_combo.clear()
        for v in self.tts.get_voices():
            self.voice_combo.addItem(v["name"], v["id"])

    def _preview_voice(self):
        voice_id = self.voice_combo.currentData() or ""
        speed    = self.speed_slider.value() / 100.0
        self.tts.stop()   # stop any current narration before preview
        self.tts.set_engine(self.engine_combo.currentText())
        self.tts.set_voice(voice_id)
        self.tts.set_speed(speed)
        self.tts.preview_voice(voice_id)

    def _browse_export(self):
        d = QFileDialog.getExistingDirectory(self, "Export Directory",
                                              self.export_dir_edit.text())
        if d:
            self.export_dir_edit.setText(d)

    def _save_and_accept(self):
        s = QSettings(ORG_SLUG, APP_SLUG)
        s.setValue("tts/engine",  self.engine_combo.currentText())
        s.setValue("tts/voice",   self.voice_combo.currentData())
        s.setValue("tts/speed",   self.speed_slider.value() / 100.0)
        s.setValue("tts/volume",  self.vol_slider.value() / 100.0)
        s.setValue("reader/font", self.font_combo.currentText())
        s.setValue("export/dir",  self.export_dir_edit.text())
        self.tts.set_engine(self.engine_combo.currentText())
        self.tts.set_voice(self.voice_combo.currentData() or "")
        self.tts.set_speed(self.speed_slider.value() / 100.0)
        self.tts.set_volume(self.vol_slider.value() / 100.0)
        self.accept()


# =============================================================================
# BOOKMARK MANAGER
# =============================================================================

class BookmarkManagerDialog(QDialog):
    jump_requested = pyqtSignal(int, int)

    def __init__(self, db: Database, file_path: str, book_title: str,
                 chapters: list[Chapter], parent=None):
        super().__init__(parent)
        self.db = db
        self.file_path = file_path
        self.chapters = chapters
        self.setWindowTitle(f"Bookmarks - {book_title}")
        self.resize(550, 400)
        self._build_ui()
        self._refresh()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        self.list_widget = QListWidget()
        self.list_widget.itemDoubleClicked.connect(self._jump)
        layout.addWidget(self.list_widget)
        row = QHBoxLayout()
        for label, slot in [("Jump To", self._jump), ("Edit", self._edit), ("Delete", self._delete)]:
            btn = QPushButton(label)
            btn.clicked.connect(slot)
            row.addWidget(btn)
        row.addStretch()
        layout.addLayout(row)
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.accept)
        layout.addWidget(close_btn)

    def _refresh(self):
        self.list_widget.clear()
        self._bookmarks = self.db.get_bookmarks(self.file_path)
        for bm in self._bookmarks:
            ch_title = self.chapters[bm["chapter_index"]].title if 0 <= bm["chapter_index"] < len(self.chapters) else ""
            label = bm["label"] or f"Bookmark @ {ch_title}"
            note  = f" - {bm['note']}" if bm["note"] else ""
            item  = QListWidgetItem(f"{label}{note}  [{ch_title}, sentence {bm['sentence_index']+1}]")
            item.setData(Qt.ItemDataRole.UserRole, bm["id"])
            self.list_widget.addItem(item)

    def _current_bm(self):
        item = self.list_widget.currentItem()
        if not item:
            return None
        bm_id = item.data(Qt.ItemDataRole.UserRole)
        return next((bm for bm in self._bookmarks if bm["id"] == bm_id), None)

    def _jump(self, *_):
        bm = self._current_bm()
        if bm:
            self.jump_requested.emit(bm["chapter_index"], bm["sentence_index"])
            self.accept()

    def _edit(self):
        bm = self._current_bm()
        if not bm:
            return
        label, ok = QInputDialog.getText(self, "Edit Label", "Label:", text=bm["label"])
        if not ok:
            return
        note, ok2 = QInputDialog.getText(self, "Edit Note", "Note:", text=bm["note"])
        self.db.update_bookmark(bm["id"], label, note if ok2 else bm["note"])
        self._refresh()

    def _delete(self):
        bm = self._current_bm()
        if not bm:
            return
        if QMessageBox.question(self, "Delete", "Delete this bookmark?",
                                 QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
                                 ) == QMessageBox.StandardButton.Yes:
            self.db.delete_bookmark(bm["id"])
            self._refresh()


# =============================================================================
# EXPORT DIALOG
# =============================================================================

class ExportDialog(QDialog):
    def __init__(self, book: Book, tts: TTSManager, parent=None):
        super().__init__(parent)
        self.book   = book
        self.tts    = tts
        self.worker: Optional[ExportWorker] = None
        self.setWindowTitle(f"Export - {book.title}")
        self.resize(500, 380)
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)

        grp = QGroupBox("Chapters to Export")
        gl  = QVBoxLayout(grp)
        self.chapter_list = QListWidget()
        self.chapter_list.setSelectionMode(QListWidget.SelectionMode.MultiSelection)
        for ch in self.book.chapters:
            item = QListWidgetItem(ch.title)
            item.setData(Qt.ItemDataRole.UserRole, ch.index)
            self.chapter_list.addItem(item)
            item.setSelected(True)
        gl.addWidget(self.chapter_list)
        row = QHBoxLayout()
        all_btn  = QPushButton("All")
        none_btn = QPushButton("None")
        all_btn.clicked.connect(lambda: [self.chapter_list.item(i).setSelected(True)
                                          for i in range(self.chapter_list.count())])
        none_btn.clicked.connect(lambda: [self.chapter_list.item(i).setSelected(False)
                                           for i in range(self.chapter_list.count())])
        row.addWidget(all_btn); row.addWidget(none_btn); row.addStretch()
        gl.addLayout(row)
        layout.addWidget(grp)

        s = QSettings(ORG_SLUG, APP_SLUG)
        default_dir = str(Path(s.value("export/dir",
            str(Path.home() / "Music" / "NarratorOfDeath"))) /
            re.sub(r'[^\w]', '_', self.book.title))

        layout.addWidget(QLabel("Output Directory:"))
        dir_row = QHBoxLayout()
        self.dir_edit = QLineEdit(default_dir)
        browse_btn = QPushButton("Browse...")
        browse_btn.clicked.connect(self._browse)
        dir_row.addWidget(self.dir_edit)
        dir_row.addWidget(browse_btn)
        layout.addLayout(dir_row)

        self.m4b_check = QCheckBox("Combine into M4B audiobook after export")
        layout.addWidget(self.m4b_check)

        self.progress_label = QLabel("Ready.")
        self.progress_bar   = QProgressBar()
        layout.addWidget(self.progress_label)
        layout.addWidget(self.progress_bar)

        btn_row = QHBoxLayout()
        self.export_btn = QPushButton("Export")
        self.cancel_btn = QPushButton("Cancel")
        self.close_btn  = QPushButton("Close")
        self.export_btn.clicked.connect(self._start_export)
        self.cancel_btn.clicked.connect(self._cancel_export)
        self.close_btn.clicked.connect(self.accept)
        self.cancel_btn.setEnabled(False)
        btn_row.addWidget(self.export_btn)
        btn_row.addWidget(self.cancel_btn)
        btn_row.addStretch()
        btn_row.addWidget(self.close_btn)
        layout.addLayout(btn_row)

    def _browse(self):
        d = QFileDialog.getExistingDirectory(self, "Output Directory", self.dir_edit.text())
        if d:
            self.dir_edit.setText(d)

    def _start_export(self):
        indices = [self.chapter_list.item(i).data(Qt.ItemDataRole.UserRole)
                   for i in range(self.chapter_list.count())
                   if self.chapter_list.item(i).isSelected()]
        if not indices:
            QMessageBox.warning(self, "No Chapters", "Select at least one chapter.")
            return
        engine = self.tts._current_engine
        if not engine:
            QMessageBox.critical(self, "No Engine", "No TTS engine available.")
            return
        if FFMPEG_PATH == "ffmpeg" and not shutil.which("ffmpeg"):
            QMessageBox.critical(self, "ffmpeg Not Found",
                                  "ffmpeg is required for export.\n"
                                  "Place ffmpeg.exe next to the application.")
            return

        self.worker = ExportWorker(
            self.book, indices, self.dir_edit.text(),
            engine, self.tts._voice_id, self.tts._speed, self.tts._volume,
            stitch_m4b=self.m4b_check.isChecked()
        )
        self.worker.progress.connect(self._on_progress)
        self.worker.finished.connect(self._on_finished)
        self.worker.error.connect(self._on_error)
        self.worker.start()
        self.export_btn.setEnabled(False)
        self.cancel_btn.setEnabled(True)

    def _cancel_export(self):
        if self.worker:
            self.worker.cancel()
        self.cancel_btn.setEnabled(False)
        self.export_btn.setEnabled(True)
        self.progress_label.setText("Cancelled.")

    def _on_progress(self, current, total, label):
        self.progress_bar.setMaximum(max(total, 1))
        self.progress_bar.setValue(current)
        self.progress_label.setText(label)

    def _on_finished(self, out_dir):
        self.cancel_btn.setEnabled(False)
        self.export_btn.setEnabled(True)
        self.progress_bar.setValue(self.progress_bar.maximum())
        self.progress_label.setText(f"Done! Saved to: {out_dir}")
        QMessageBox.information(self, "Export Complete", f"Audio saved to:\n{out_dir}")

    def _on_error(self, msg):
        self.cancel_btn.setEnabled(False)
        self.export_btn.setEnabled(True)
        self.progress_label.setText("Export failed.")
        QMessageBox.critical(self, "Export Error", msg)

    def closeEvent(self, event):
        if self.worker and self.worker.isRunning():
            self.worker.cancel()
            self.worker.wait(3000)
        super().closeEvent(event)


# =============================================================================
# READER PANEL
# =============================================================================

class ReaderPanel(QWidget):
    sentence_clicked = pyqtSignal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._sentences: list[str] = []
        self._current_idx = -1
        self._font_family = "Georgia"
        self._font_size   = 14
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self.text_edit = QTextEdit()
        self.text_edit.setReadOnly(True)
        self.text_edit.setStyleSheet(f"""
            QTextEdit {{
                background-color: {READER_BG};
                color: {READER_TEXT};
                border: none;
                padding: 20px 40px;
            }}
            QScrollBar:vertical {{
                background: #ddd; width: 10px;
            }}
            QScrollBar::handle:vertical {{
                background: #aaa; border-radius: 5px;
            }}
        """)
        self.text_edit.mousePressEvent = self._on_mouse_press
        layout.addWidget(self.text_edit)

    def load_chapter(self, chapter: Chapter):
        self._sentences   = chapter.sentences
        self._current_idx = -1
        self._offsets     = []
        self._full_render()

    def _full_render(self):
        """Full rerender — only called on chapter load or font change."""
        self.text_edit.clear()
        cursor = self.text_edit.textCursor()
        normal_fmt = self._normal_fmt()
        hl_fmt     = self._hl_fmt()
        for i, sentence in enumerate(self._sentences):
            fmt = hl_fmt if i == self._current_idx else normal_fmt
            cursor.insertText(sentence, fmt)
            cursor.insertText(" ", normal_fmt)
        self.text_edit.setTextCursor(cursor)
        # Store sentence byte offsets for fast lookup
        self._offsets = []
        off = 0
        for s in self._sentences:
            self._offsets.append(off)
            off += len(s) + 1

    def _normal_fmt(self) -> QTextCharFormat:
        fmt = QTextCharFormat()
        fmt.setFontFamily(self._font_family)
        fmt.setFontPointSize(self._font_size)
        fmt.setBackground(QColor(READER_BG))
        fmt.setForeground(QColor(READER_TEXT))
        fmt.setFontWeight(QFont.Weight.Normal)
        return fmt

    def _hl_fmt(self) -> QTextCharFormat:
        fmt = QTextCharFormat()
        fmt.setFontFamily(self._font_family)
        fmt.setFontPointSize(self._font_size)
        fmt.setBackground(QColor(HIGHLIGHT_BG))
        fmt.setForeground(QColor(HIGHLIGHT_FG))
        fmt.setFontWeight(QFont.Weight.Bold)
        return fmt

    def _reformat_sentence(self, idx: int, fmt: QTextCharFormat):
        """Reformat a single sentence in-place — O(1) vs O(n) full rerender."""
        if idx < 0 or idx >= len(self._sentences):
            return
        if not hasattr(self, '_offsets') or idx >= len(self._offsets):
            return
        start  = self._offsets[idx]
        length = len(self._sentences[idx])
        doc    = self.text_edit.document()
        cursor = QTextCursor(doc)
        cursor.setPosition(start)
        cursor.setPosition(start + length, QTextCursor.MoveMode.KeepAnchor)
        cursor.setCharFormat(fmt)

    def highlight_sentence(self, idx: int):
        if idx == self._current_idx:
            return
        prev_idx = self._current_idx
        self._current_idx = idx
        # Un-highlight previous sentence
        if prev_idx >= 0:
            self._reformat_sentence(prev_idx, self._normal_fmt())
        # Highlight new sentence
        self._reformat_sentence(idx, self._hl_fmt())
        self._scroll_to(idx)

    def _scroll_to(self, idx: int):
        if idx < 0 or idx >= len(self._sentences):
            return
        offset = sum(len(s) + 1 for s in self._sentences[:idx])
        doc    = self.text_edit.document()
        cursor = self.text_edit.textCursor()
        cursor.setPosition(min(offset, doc.characterCount() - 1))
        self.text_edit.setTextCursor(cursor)
        self.text_edit.ensureCursorVisible()

    def _on_mouse_press(self, event: QMouseEvent):
        cursor = self.text_edit.cursorForPosition(event.pos())
        pos    = cursor.position()
        offset = 0
        for i, sentence in enumerate(self._sentences):
            end = offset + len(sentence) + 1
            if offset <= pos < end:
                self.sentence_clicked.emit(i)
                break
            offset = end
        QTextEdit.mousePressEvent(self.text_edit, event)

    def set_font(self, family: str, size: int):
        self._font_family = family
        self._font_size   = size
        if self._sentences:
            self._full_render()

    def current_sentence_index(self) -> int:
        return self._current_idx


# =============================================================================
# SIDEBAR
# =============================================================================

class SidebarWidget(QWidget):
    chapter_selected  = pyqtSignal(int)
    bookmark_selected = pyqtSignal(int, int)

    def __init__(self, db: Database, parent=None):
        super().__init__(parent)
        self.db = db
        self.file_path = ""
        self.chapters: list[Chapter] = []
        self._build_ui()
        self.setMaximumWidth(280)
        self.setMinimumWidth(160)

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(4, 4, 4, 4)
        self.tabs = QTabWidget()
        self.chapter_tree = QTreeWidget()
        self.chapter_tree.setHeaderHidden(True)
        self.chapter_tree.itemClicked.connect(self._on_chapter_clicked)
        self.tabs.addTab(self.chapter_tree, "Chapters")
        self.bm_list = QListWidget()
        self.bm_list.itemDoubleClicked.connect(self._on_bookmark_clicked)
        self.tabs.addTab(self.bm_list, "Bookmarks")
        layout.addWidget(self.tabs)

    def load_book(self, book: Book):
        self.file_path = book.file_path
        self.chapters  = book.chapters
        self.chapter_tree.clear()
        for ch in book.chapters:
            item = QTreeWidgetItem([ch.title])
            item.setData(0, Qt.ItemDataRole.UserRole, ch.index)
            self.chapter_tree.addTopLevelItem(item)
        self.refresh_bookmarks()

    def refresh_bookmarks(self):
        self.bm_list.clear()
        if not self.file_path:
            return
        for bm in self.db.get_bookmarks(self.file_path):
            ch_title = self.chapters[bm["chapter_index"]].title if 0 <= bm["chapter_index"] < len(self.chapters) else ""
            label = bm["label"] or f"@ {ch_title}"
            item  = QListWidgetItem(f"[BM] {label}")
            item.setData(Qt.ItemDataRole.UserRole, (bm["chapter_index"], bm["sentence_index"]))
            self.bm_list.addItem(item)

    def highlight_chapter(self, idx: int):
        for i in range(self.chapter_tree.topLevelItemCount()):
            item = self.chapter_tree.topLevelItem(i)
            sel  = item.data(0, Qt.ItemDataRole.UserRole) == idx
            item.setSelected(sel)
            if sel:
                self.chapter_tree.scrollToItem(item)

    def _on_chapter_clicked(self, item, _):
        self.chapter_selected.emit(item.data(0, Qt.ItemDataRole.UserRole))

    def _on_bookmark_clicked(self, item):
        ci, si = item.data(Qt.ItemDataRole.UserRole)
        self.bookmark_selected.emit(ci, si)


# =============================================================================
# CONTROLS BAR
# =============================================================================

class ControlsBar(QWidget):
    play_clicked      = pyqtSignal()
    pause_clicked     = pyqtSignal()
    stop_clicked      = pyqtSignal()
    prev_sentence     = pyqtSignal()
    next_sentence     = pyqtSignal()
    prev_chapter      = pyqtSignal()
    next_chapter      = pyqtSignal()
    speed_changed     = pyqtSignal(float)
    font_size_changed = pyqtSignal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._playing  = False
        self._font_size = 14
        self._build_ui()

    def _btn(self, text: str, tip: str = "", width: int = 36) -> QPushButton:
        b = QPushButton(text)
        b.setToolTip(tip)
        b.setFixedWidth(width)
        return b

    def _build_ui(self):
        self.setStyleSheet(f"QWidget {{ background: {UI_BG2}; border-top: 1px solid {BORDER}; }}")
        layout = QHBoxLayout(self)
        layout.setContentsMargins(8, 4, 8, 4)

        self.prev_ch_btn = self._btn("|<", "Prev Chapter (Ctrl+Left)")
        self.prev_s_btn  = self._btn("<",  "Prev Sentence (Left)")
        self.play_btn    = self._btn(">",  "Play (Space)", 44)
        self.stop_btn    = self._btn("[]", "Stop")
        self.next_s_btn  = self._btn(">",  "Next Sentence (Right)")
        self.next_ch_btn = self._btn(">|", "Next Chapter (Ctrl+Right)")

        self.prev_ch_btn.clicked.connect(self.prev_chapter)
        self.prev_s_btn.clicked.connect(self.prev_sentence)
        self.play_btn.clicked.connect(self._on_play)
        self.stop_btn.clicked.connect(self.stop_clicked)
        self.next_s_btn.clicked.connect(self.next_sentence)
        self.next_ch_btn.clicked.connect(self.next_chapter)

        for btn in [self.prev_ch_btn, self.prev_s_btn, self.play_btn,
                    self.stop_btn, self.next_s_btn, self.next_ch_btn]:
            layout.addWidget(btn)

        layout.addSpacing(12)
        layout.addWidget(QLabel("Speed:"))
        self.speed_slider = QSlider(Qt.Orientation.Horizontal)
        self.speed_slider.setRange(50, 300)
        self.speed_slider.setValue(100)
        self.speed_slider.setFixedWidth(100)
        self.speed_label = QLabel("1.0x")
        self.speed_slider.valueChanged.connect(self._on_speed)
        layout.addWidget(self.speed_slider)
        layout.addWidget(self.speed_label)

        layout.addSpacing(12)
        layout.addWidget(QLabel("Font:"))
        self.font_minus = self._btn("-", "Smaller Font (Ctrl+-)")
        self.font_plus  = self._btn("+", "Larger Font (Ctrl+=)")
        self.font_lbl   = QLabel("14")
        self.font_minus.clicked.connect(self._font_decrease)
        self.font_plus.clicked.connect(self._font_increase)
        layout.addWidget(self.font_minus)
        layout.addWidget(self.font_lbl)
        layout.addWidget(self.font_plus)
        layout.addStretch()

    def _on_play(self):
        if self._playing:
            self.pause_clicked.emit()
        else:
            self.play_clicked.emit()

    def set_playing(self, playing: bool):
        self._playing = playing
        self.play_btn.setText("||" if playing else ">")

    def _on_speed(self, v: int):
        speed = v / 100.0
        self.speed_label.setText(f"{speed:.1f}x")
        self.speed_changed.emit(speed)

    def _font_decrease(self):
        self._font_size = max(8, self._font_size - 1)
        self.font_lbl.setText(str(self._font_size))
        self.font_size_changed.emit(self._font_size)

    def _font_increase(self):
        self._font_size = min(36, self._font_size + 1)
        self.font_lbl.setText(str(self._font_size))
        self.font_size_changed.emit(self._font_size)

    def get_speed(self) -> float:
        return self.speed_slider.value() / 100.0


# =============================================================================
# READER TAB
# =============================================================================

class ReaderTab(QWidget):
    title_changed = pyqtSignal(str)

    def __init__(self, book: Book, db: Database, tts: TTSManager, parent=None):
        super().__init__(parent)
        self.book = book
        self.db   = db
        self.tts  = tts

        self._chapter_idx  = 0
        self._sentence_idx = 0
        self._is_playing   = False
        self._font_family  = QSettings(ORG_SLUG, APP_SLUG).value("reader/font", "Georgia")

        ch, sent = db.get_position(book.file_path)
        self._chapter_idx  = ch
        self._sentence_idx = sent

        self._build_ui()
        self._connect_signals()
        self._load_chapter(self._chapter_idx)
        self.reader_panel.highlight_sentence(self._sentence_idx)

        # Connect TTS signals with queued connection to prevent UI freeze
        self.tts.sentence_started.connect(
            self._on_sentence_started, Qt.ConnectionType.QueuedConnection)
        self.tts.sentence_finished.connect(
            self._on_sentence_finished, Qt.ConnectionType.QueuedConnection)
        self.tts.playback_finished.connect(
            self._on_playback_finished, Qt.ConnectionType.QueuedConnection)
        self.tts.error_occurred.connect(
            self._on_tts_error, Qt.ConnectionType.QueuedConnection)

    def _build_ui(self):
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        self.splitter = QSplitter(Qt.Orientation.Horizontal)
        self.sidebar  = SidebarWidget(self.db)
        self.sidebar.load_book(self.book)
        self.splitter.addWidget(self.sidebar)

        right = QWidget()
        rl = QVBoxLayout(right)
        rl.setContentsMargins(0, 0, 0, 0)
        rl.setSpacing(0)

        self.reader_panel = ReaderPanel()
        self.reader_panel.set_font(self._font_family, 14)
        rl.addWidget(self.reader_panel)

        self.controls = ControlsBar()
        rl.addWidget(self.controls)

        self.splitter.addWidget(right)
        self.splitter.setSizes([220, 780])
        layout.addWidget(self.splitter)

    def _connect_signals(self):
        self.sidebar.chapter_selected.connect(self._on_chapter_selected)
        self.sidebar.bookmark_selected.connect(self._on_bookmark_selected)
        self.reader_panel.sentence_clicked.connect(self._on_sentence_clicked)
        self.controls.play_clicked.connect(self._play)
        self.controls.pause_clicked.connect(self._pause)
        self.controls.stop_clicked.connect(self._stop)
        self.controls.prev_sentence.connect(self._prev_sentence)
        self.controls.next_sentence.connect(self._next_sentence)
        self.controls.prev_chapter.connect(self._prev_chapter)
        self.controls.next_chapter.connect(self._next_chapter)
        self.controls.speed_changed.connect(self.tts.set_speed)
        self.controls.font_size_changed.connect(self._on_font_size_changed)

    def _load_chapter(self, idx: int):
        if not self.book.chapters:
            return
        idx = max(0, min(idx, len(self.book.chapters) - 1))
        self._chapter_idx = idx
        chapter = self.book.chapters[idx]
        self.reader_panel.load_chapter(chapter)
        self.sidebar.highlight_chapter(idx)
        self.title_changed.emit(f"{self.book.title} - {chapter.title}")

    def _play(self):
        if not self.book.chapters:
            return
        chapter = self.book.chapters[self._chapter_idx]
        self._is_playing = True
        self.controls.set_playing(True)
        self.tts.play(chapter.sentences, self._sentence_idx)

    def _pause(self):
        if self._is_playing:
            self.tts.pause()
            self._is_playing = False
            self.controls.set_playing(False)
        else:
            self.tts.resume()
            self._is_playing = True
            self.controls.set_playing(True)

    def _stop(self):
        self.tts.stop()
        self._is_playing = False
        self.controls.set_playing(False)
        self._save_position()

    def _prev_sentence(self):
        self._stop()
        self._sentence_idx = max(0, self._sentence_idx - 1)
        self.reader_panel.highlight_sentence(self._sentence_idx)

    def _next_sentence(self):
        self._stop()
        if self.book.chapters:
            mx = len(self.book.chapters[self._chapter_idx].sentences) - 1
            self._sentence_idx = min(mx, self._sentence_idx + 1)
        self.reader_panel.highlight_sentence(self._sentence_idx)

    def _prev_chapter(self):
        self._stop(); self._sentence_idx = 0
        self._load_chapter(self._chapter_idx - 1)

    def _next_chapter(self):
        self._stop(); self._sentence_idx = 0
        self._load_chapter(self._chapter_idx + 1)

    def _on_chapter_selected(self, idx: int):
        self._stop(); self._sentence_idx = 0; self._load_chapter(idx)

    def _on_bookmark_selected(self, ci: int, si: int):
        self._stop(); self._load_chapter(ci)
        self._sentence_idx = si
        self.reader_panel.highlight_sentence(si)

    def _on_sentence_clicked(self, idx: int):
        was_playing = self._is_playing
        self._stop()
        self._sentence_idx = idx
        self.reader_panel.highlight_sentence(idx)
        if was_playing:
            self._play()

    def _on_sentence_started(self, idx: int):
        self._sentence_idx = idx
        self.reader_panel.highlight_sentence(idx)

    def _on_sentence_finished(self, idx: int):
        self._save_position()

    def _on_playback_finished(self):
        if self._chapter_idx < len(self.book.chapters) - 1:
            self._sentence_idx = 0
            self._load_chapter(self._chapter_idx + 1)
            self._play()
        else:
            self._is_playing = False
            self.controls.set_playing(False)

    def _on_tts_error(self, msg: str):
        self._is_playing = False
        self.controls.set_playing(False)
        log.error(f"TTS error: {msg}")

    def _on_font_size_changed(self, size: int):
        self.reader_panel.set_font(self._font_family, size)

    def _save_position(self):
        self.db.save_position(self.book.file_path, self._chapter_idx, self._sentence_idx)

    def add_bookmark(self):
        if not self.book.chapters:
            return
        label, ok = QInputDialog.getText(self, "Add Bookmark", "Label (optional):")
        if not ok:
            return
        note, ok2 = QInputDialog.getText(self, "Add Bookmark", "Note (optional):")
        self.db.add_bookmark(self.book.file_path, self._chapter_idx,
                              self._sentence_idx, label, note if ok2 else "")
        self.sidebar.refresh_bookmarks()

    def show_bookmarks(self):
        dlg = BookmarkManagerDialog(self.db, self.book.file_path,
                                     self.book.title, self.book.chapters, self)
        dlg.jump_requested.connect(self._on_bookmark_selected)
        dlg.exec()

    def show_export(self):
        ExportDialog(self.book, self.tts, self).exec()

    def release_ownership(self):
        if self._is_playing:
            self._pause()

    def take_ownership(self):
        pass

    def closeEvent(self, event):
        self._stop()
        self._save_position()
        super().closeEvent(event)


# =============================================================================
# HOME TAB
# =============================================================================

class BookCard(QFrame):
    open_requested   = pyqtSignal(str)
    remove_requested = pyqtSignal(str)

    def __init__(self, row, cover: QPixmap, parent=None):
        super().__init__(parent)
        self.file_path = row["file_path"]
        self.setFixedSize(180, 280)
        self.setStyleSheet(f"""
            QFrame {{ background: {UI_BG2}; border: 1px solid {BORDER}; border-radius: 6px; }}
            QFrame:hover {{ border: 2px solid {ACCENT_RED}; }}
        """)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(4)
        cover_lbl = QLabel()
        cover_lbl.setPixmap(cover.scaled(160, 200, Qt.AspectRatioMode.KeepAspectRatio,
                                          Qt.TransformationMode.SmoothTransformation))
        cover_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(cover_lbl)
        title = row["title"] or Path(row["file_path"]).stem
        tl = QLabel(title[:25] + "..." if len(title) > 25 else title)
        tl.setWordWrap(True)
        tl.setStyleSheet(f"font-weight: bold; font-size: 10px; color: {UI_TEXT};")
        tl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(tl)
        if row["author"]:
            al = QLabel(row["author"][:22] + "..." if len(row["author"]) > 22 else row["author"])
            al.setStyleSheet(f"font-size: 9px; color: {UI_TEXT_DIM};")
            al.setAlignment(Qt.AlignmentFlag.AlignCenter)
            layout.addWidget(al)

    def mouseDoubleClickEvent(self, event):
        self.open_requested.emit(self.file_path)

    def contextMenuEvent(self, event):
        from PyQt6.QtWidgets import QMenu
        menu = QMenu(self)
        open_act   = menu.addAction("Open")
        remove_act = menu.addAction("Remove from Library")
        action = menu.exec(event.globalPos())
        if action == open_act:
            self.open_requested.emit(self.file_path)
        elif action == remove_act:
            self.remove_requested.emit(self.file_path)


class HomeTab(QWidget):
    open_book_requested = pyqtSignal(str)

    def __init__(self, db: Database, parent=None):
        super().__init__(parent)
        self.db = db
        self._view_mode = "grid"
        self._build_ui()
        self.refresh()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        toolbar = QWidget()
        toolbar.setStyleSheet(f"QWidget {{ background: {DARK_RED}; }}")
        tb = QHBoxLayout(toolbar)
        tb.setContentsMargins(8, 4, 8, 4)
        title_lbl = QLabel(f"  {APP_NAME} Library")
        title_lbl.setStyleSheet(f"color: white; font-family: {APP_FONT}; font-size: 14px; font-weight: bold; background: transparent;")
        tb.addWidget(title_lbl)
        tb.addStretch()

        self.grid_btn = QPushButton("Grid")
        self.list_btn = QPushButton("List")
        for btn in [self.grid_btn, self.list_btn]:
            btn.setCheckable(True)
            btn.setStyleSheet("""
                QPushButton { background: rgba(255,255,255,0.2); color: white;
                              border: 1px solid rgba(255,255,255,0.4);
                              border-radius: 4px; padding: 4px 12px; }
                QPushButton:hover { background: rgba(255,255,255,0.35); }
                QPushButton:checked { background: rgba(255,255,255,0.5); }
            """)
        s = QSettings(ORG_SLUG, APP_SLUG)
        self._view_mode = s.value("shelf/view_mode", "grid")
        self.grid_btn.setChecked(self._view_mode == "grid")
        self.list_btn.setChecked(self._view_mode == "list")
        self.grid_btn.clicked.connect(lambda: self._set_view("grid"))
        self.list_btn.clicked.connect(lambda: self._set_view("list"))
        tb.addWidget(self.grid_btn)
        tb.addWidget(self.list_btn)
        layout.addWidget(toolbar)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setStyleSheet(f"QScrollArea {{ background: {UI_BG}; border: none; }}")
        layout.addWidget(self.scroll)

        self.empty_label = QLabel("No books yet.\n\nOpen a file to add it to your library.")
        self.empty_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.empty_label.setStyleSheet(f"color: {UI_TEXT_DIM}; font-size: 14px; background: {UI_BG};")

    def _set_view(self, mode: str):
        self._view_mode = mode
        self.grid_btn.setChecked(mode == "grid")
        self.list_btn.setChecked(mode == "list")
        QSettings(ORG_SLUG, APP_SLUG).setValue("shelf/view_mode", mode)
        self.refresh()

    def refresh(self):
        rows = self.db.get_library()
        if not rows:
            self.scroll.setWidget(self.empty_label)
            return

        container = QWidget()
        container.setStyleSheet(f"background: {UI_BG};")

        if self._view_mode == "grid":
            grid = QGridLayout(container)
            grid.setContentsMargins(16, 16, 16, 16)
            grid.setSpacing(16)
            col_count = 5
            for n, row in enumerate(rows):
                fake = type('B', (), {
                    'file_path': row['file_path'],
                    'title': row['title'] or '',
                    'file_hash': row['file_hash'] or '',
                    'cover_pixmap': None
                })()
                cover = get_or_create_cover(fake)
                card  = BookCard(row, cover)
                card.open_requested.connect(self.open_book_requested)
                card.remove_requested.connect(self._remove_book)
                grid.addWidget(card, n // col_count, n % col_count)
        else:
            vl = QVBoxLayout(container)
            vl.setContentsMargins(16, 16, 16, 16)
            vl.setSpacing(8)
            for row in rows:
                vl.addWidget(self._make_list_item(row))
            vl.addStretch()

        self.scroll.setWidget(container)

    def _make_list_item(self, row) -> QWidget:
        frame = QFrame()
        frame.setStyleSheet(f"""
            QFrame {{ background: {UI_BG2}; border: 1px solid {BORDER}; border-radius: 4px; }}
            QFrame:hover {{ border: 1px solid {ACCENT_RED}; }}
        """)
        frame.setFixedHeight(70)
        frame.setCursor(Qt.CursorShape.PointingHandCursor)
        h = QHBoxLayout(frame)
        h.setContentsMargins(8, 8, 8, 8)
        fake = type('B', (), {
            'file_path': row['file_path'],
            'title': row['title'] or '',
            'file_hash': row['file_hash'] or '',
            'cover_pixmap': None
        })()
        cover = get_or_create_cover(fake, QSize(40, 55))
        cl = QLabel(); cl.setPixmap(cover)
        h.addWidget(cl)
        info = QVBoxLayout()
        tl = QLabel(row["title"] or Path(row["file_path"]).stem)
        tl.setStyleSheet(f"font-weight: bold; color: {UI_TEXT}; background: transparent;")
        al = QLabel(row["author"] or "Unknown Author")
        al.setStyleSheet(f"color: {UI_TEXT_DIM}; font-size: 11px; background: transparent;")
        info.addWidget(tl); info.addWidget(al)
        h.addLayout(info); h.addStretch()
        fp = row["file_path"]
        ob = QPushButton("Open")
        rb = QPushButton("Remove")
        ob.clicked.connect(lambda: self.open_book_requested.emit(fp))
        rb.clicked.connect(lambda: self._remove_book(fp))
        h.addWidget(ob); h.addWidget(rb)
        return frame

    def _remove_book(self, file_path: str):
        if QMessageBox.question(self, "Remove",
                                 "Remove from library? (File will not be deleted.)",
                                 QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
                                 ) == QMessageBox.StandardButton.Yes:
            self.db.remove_from_library(file_path)
            self.refresh()


# =============================================================================
# MAIN WINDOW
# =============================================================================

class MainWindow(QMainWindow):
    def __init__(self, db: Database, tts: TTSManager):
        super().__init__()
        self.db  = db
        self.tts = tts
        self._prev_tab_idx = 0

        self.setWindowTitle(APP_NAME)
        self.resize(1200, 800)

        # Status bar FIRST — _on_tab_changed references it
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage(f"{APP_NAME} - {ORG_NAME}")

        self._build_ui()
        self._build_menu()
        self._build_shortcuts()
        self._restore_geometry()

    def _build_ui(self):
        self.tab_widget = QTabWidget()
        self.tab_widget.setTabsClosable(True)
        self.tab_widget.tabCloseRequested.connect(self._close_tab)
        self.tab_widget.currentChanged.connect(self._on_tab_changed)

        self.home_tab = HomeTab(self.db)
        self.home_tab.open_book_requested.connect(self.open_file_path)
        self.tab_widget.addTab(self.home_tab, "Library")

        # Remove close button from home tab without passing None
        empty = QWidget()
        empty.setFixedSize(0, 0)
        self.tab_widget.tabBar().setTabButton(
            0, self.tab_widget.tabBar().ButtonPosition.RightSide, empty)

        self.setCentralWidget(self.tab_widget)

    def _build_menu(self):
        mb = self.menuBar()

        file_menu = mb.addMenu("File")
        for label, shortcut, slot in [
            ("Open File...", "Ctrl+O", self.open_file_dialog),
            ("Close Tab",    "Ctrl+W", self._close_current_tab),
            ("Quit",         "Ctrl+Q", self.close),
        ]:
            act = QAction(label, self)
            if shortcut:
                act.setShortcut(QKeySequence(shortcut))
            act.triggered.connect(slot)
            if label == "Close Tab":
                file_menu.addSeparator()
            if label == "Quit":
                file_menu.addSeparator()
            file_menu.addAction(act)

        play_menu = mb.addMenu("Playback")
        for label, shortcut, slot in [
            ("Play / Pause",  "Space",      self._space_action),
            ("Stop",          "Ctrl+.",     self._stop_action),
            ("Prev Sentence", "Left",       self._prev_sentence_action),
            ("Next Sentence", "Right",      self._next_sentence_action),
            ("Prev Chapter",  "Ctrl+Left",  self._prev_chapter_action),
            ("Next Chapter",  "Ctrl+Right", self._next_chapter_action),
        ]:
            act = QAction(label, self)
            act.setShortcut(QKeySequence(shortcut))
            act.triggered.connect(slot)
            play_menu.addAction(act)

        book_menu = mb.addMenu("Book")
        for label, shortcut, slot in [
            ("Add Bookmark",       "Ctrl+B", self._add_bookmark_action),
            ("Manage Bookmarks...", "",      self._show_bookmarks_action),
            ("Export to MP3...",   "Ctrl+E", self._export_action),
        ]:
            act = QAction(label, self)
            if shortcut:
                act.setShortcut(QKeySequence(shortcut))
            act.triggered.connect(slot)
            if label == "Export to MP3...":
                book_menu.addSeparator()
            book_menu.addAction(act)

        view_menu = mb.addMenu("View")
        for label, shortcut, slot in [
            ("Font Larger",       "Ctrl+=", self._font_increase_action),
            ("Font Smaller",      "Ctrl+-", self._font_decrease_action),
            ("Toggle Fullscreen", "F11",    self._toggle_fullscreen),
        ]:
            act = QAction(label, self)
            act.setShortcut(QKeySequence(shortcut))
            act.triggered.connect(slot)
            view_menu.addAction(act)

        settings_menu = mb.addMenu("Settings")
        pref = QAction("Preferences...", self)
        pref.setShortcut(QKeySequence("Ctrl+,"))
        pref.triggered.connect(self._show_settings)
        settings_menu.addAction(pref)

    def _build_shortcuts(self):
        from PyQt6.QtGui import QShortcut
        QShortcut(QKeySequence("Ctrl+Tab"),       self, self._next_tab)
        QShortcut(QKeySequence("Ctrl+Shift+Tab"), self, self._prev_tab)
        QShortcut(QKeySequence("Escape"),         self, self._esc_action)

    def _current_reader(self) -> Optional[ReaderTab]:
        w = self.tab_widget.currentWidget()
        return w if isinstance(w, ReaderTab) else None

    def _reader_count(self) -> int:
        return sum(1 for i in range(self.tab_widget.count())
                   if isinstance(self.tab_widget.widget(i), ReaderTab))

    def _on_tab_changed(self, idx: int):
        if not hasattr(self, "status_bar") or not hasattr(self, "tab_widget"):
            return
        try:
            prev = self.tab_widget.widget(self._prev_tab_idx)
            if isinstance(prev, ReaderTab):
                prev.release_ownership()
            self._prev_tab_idx = idx
            curr = self.tab_widget.widget(idx)
            if isinstance(curr, ReaderTab):
                curr.take_ownership()
                self.status_bar.showMessage(curr.book.title)
            else:
                self.status_bar.showMessage(f"{APP_NAME} - {ORG_NAME}")
        except Exception as e:
            log.error(f"Tab change error: {e}")

    def open_file_dialog(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Open Book", str(Path.home()), supported_filter())
        if path:
            self.open_file_path(path)

    def open_file_path(self, file_path: str):
        if not Path(file_path).exists():
            QMessageBox.warning(self, "Not Found", f"File not found:\n{file_path}")
            return
        # Already open?
        for i in range(self.tab_widget.count()):
            w = self.tab_widget.widget(i)
            if isinstance(w, ReaderTab) and w.book.file_path == file_path:
                self.tab_widget.setCurrentIndex(i)
                return
        if self._reader_count() >= MAX_TABS:
            QMessageBox.warning(self, "Too Many Tabs",
                                 f"Maximum {MAX_TABS} books open. Close a tab first.")
            return

        self.status_bar.showMessage("Loading...")
        QApplication.processEvents()

        try:
            book = parse_book(file_path)
        except Exception as e:
            QMessageBox.critical(self, "Parse Error", f"Could not open file:\n{e}")
            self.status_bar.showMessage("Load failed.")
            return

        get_or_create_cover(book)
        self.db.upsert_library(file_path, book.title, book.author,
                                str(COVERS_DIR / f"{book.file_hash}.png"), book.file_hash)
        self.home_tab.refresh()

        reader = ReaderTab(book, self.db, self.tts)
        reader.title_changed.connect(lambda t, r=reader: self._update_tab_title(r))
        short = book.title[:20] + "..." if len(book.title) > 20 else book.title
        idx = self.tab_widget.addTab(reader, short)
        self.tab_widget.setCurrentIndex(idx)
        self.status_bar.showMessage(f"Opened: {book.title}")

    def _update_tab_title(self, reader: ReaderTab):
        for i in range(self.tab_widget.count()):
            if self.tab_widget.widget(i) is reader:
                short = reader.book.title[:16] + "..." if len(reader.book.title) > 16 else reader.book.title
                self.tab_widget.setTabText(i, short)
                break

    def _close_tab(self, idx: int):
        if idx == 0:
            return
        w = self.tab_widget.widget(idx)
        if isinstance(w, ReaderTab):
            w._stop()
            w._save_position()
        self.tab_widget.removeTab(idx)

    def _close_current_tab(self):
        idx = self.tab_widget.currentIndex()
        if idx > 0:
            self._close_tab(idx)

    def _next_tab(self):
        n = self.tab_widget.count()
        self.tab_widget.setCurrentIndex((self.tab_widget.currentIndex() + 1) % n)

    def _prev_tab(self):
        n = self.tab_widget.count()
        self.tab_widget.setCurrentIndex((self.tab_widget.currentIndex() - 1) % n)

    def _space_action(self):
        r = self._current_reader()
        if r:
            r._pause() if r._is_playing else r._play()

    def _stop_action(self):
        if r := self._current_reader(): r._stop()

    def _prev_sentence_action(self):
        if r := self._current_reader(): r._prev_sentence()

    def _next_sentence_action(self):
        if r := self._current_reader(): r._next_sentence()

    def _prev_chapter_action(self):
        if r := self._current_reader(): r._prev_chapter()

    def _next_chapter_action(self):
        if r := self._current_reader(): r._next_chapter()

    def _add_bookmark_action(self):
        if r := self._current_reader(): r.add_bookmark()

    def _show_bookmarks_action(self):
        if r := self._current_reader(): r.show_bookmarks()

    def _export_action(self):
        if r := self._current_reader(): r.show_export()

    def _font_increase_action(self):
        if r := self._current_reader(): r.controls._font_increase()

    def _font_decrease_action(self):
        if r := self._current_reader(): r.controls._font_decrease()

    def _toggle_fullscreen(self):
        self.showNormal() if self.isFullScreen() else self.showFullScreen()

    def _esc_action(self):
        if self.isFullScreen(): self.showNormal()

    def _show_settings(self):
        dlg = SettingsDialog(self.tts, self)
        dlg.exec()
        font = QSettings(ORG_SLUG, APP_SLUG).value("reader/font", "Georgia")
        for i in range(self.tab_widget.count()):
            w = self.tab_widget.widget(i)
            if isinstance(w, ReaderTab):
                w._font_family = font
                w.reader_panel.set_font(font, 14)

    def _restore_geometry(self):
        geom = QSettings(ORG_SLUG, APP_SLUG).value("window/geometry")
        if geom:
            self.restoreGeometry(geom)

    def closeEvent(self, event):
        QSettings(ORG_SLUG, APP_SLUG).setValue("window/geometry", self.saveGeometry())
        for i in range(self.tab_widget.count()):
            w = self.tab_widget.widget(i)
            if isinstance(w, ReaderTab):
                w._stop()
                w._save_position()
        self.tts.stop()
        self.db.close()
        super().closeEvent(event)


# =============================================================================
# ENTRY POINT
# =============================================================================

def main():
    def _excepthook(exc_type, exc_value, exc_tb):
        import traceback
        traceback.print_exception(exc_type, exc_value, exc_tb)
        log.error("Unhandled exception", exc_info=(exc_type, exc_value, exc_tb))
    sys.excepthook = _excepthook

    # Windows: set App User Model ID so taskbar shows the correct icon
    # and groups the window as its own app rather than under Python
    if sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
                "DeathsHeadSoftware.NarratorOfDeath.1.0"
            )
        except Exception as e:
            log.warning(f"Could not set AppUserModelID: {e}")

    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setOrganizationName(ORG_NAME)
    app.setApplicationVersion(APP_VERSION)
    app.setStyleSheet(dark_stylesheet())

    # Set application icon — next to script, or next to frozen exe
    def _find_icon() -> Optional[str]:
        candidates = [Path(__file__).parent / "icon.ico"]
        if getattr(sys, "frozen", False):
            candidates.append(Path(sys.executable).parent / "icon.ico")
        for p in candidates:
            if p.exists():
                return str(p)
        return None

    icon_path = _find_icon()
    if icon_path:
        app.setWindowIcon(QIcon(icon_path))

    splash = create_splash()
    if splash:
        splash.show()
        app.processEvents()

    def _msg(m: str):
        if splash:
            splash.showMessage("\n\n\n\n\n\n\n" + m,
                               Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignCenter,
                               QColor(255, 255, 255))
            app.processEvents()

    _msg("Initializing database...")
    db = Database()

    _msg("Loading TTS engines...")
    tts = TTSManager()

    s = QSettings(ORG_SLUG, APP_SLUG)
    if engine_name := s.value("tts/engine", ""):
        tts.set_engine(engine_name)
    if voice_id := s.value("tts/voice", ""):
        tts.set_voice(voice_id)
    tts.set_speed(float(s.value("tts/speed", 1.0)))
    tts.set_volume(float(s.value("tts/volume", 1.0)))

    _msg("Building interface...")
    window = MainWindow(db, tts)

    if splash:
        splash.finish(window)

    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
