import 'package:flutter/foundation.dart';
import 'package:flutter_tts/flutter_tts.dart';

enum TtsState { stopped, playing, paused }

class TtsManager extends ChangeNotifier {
  final FlutterTts _tts = FlutterTts();

  TtsState state = TtsState.stopped;

  List<String> _sentences   = [];
  int _currentIdx           = 0;
  bool _stopRequested       = false;

  // Settings
  double speed  = 0.5;
  double pitch  = 1.0;
  double volume = 1.0;
  String voice  = '';

  List<dynamic> _availableVoices = [];
  List<dynamic> get availableVoices => _availableVoices;

  // Callbacks for UI
  void Function(int idx)? onSentenceStart;
  void Function(int idx)? onSentenceFinish;
  void Function()?        onPlaybackFinished;
  void Function(String)?  onError;

  TtsManager() {
    _init();
  }

  Future<void> _init() async {
    await _tts.setLanguage('en-US');
    await _tts.setSpeechRate(speed);
    await _tts.setPitch(pitch);
    await _tts.setVolume(volume);
    await _tts.awaitSpeakCompletion(true);

    // Android-specific: use better quality engine if available
    try {
      await _tts.setQueueMode(1);
    } catch (_) {}

    _tts.setStartHandler(() {
      state = TtsState.playing;
      notifyListeners();
    });

    _tts.setCompletionHandler(() async {
      if (_stopRequested) return;
      onSentenceFinish?.call(_currentIdx);
      _currentIdx++;
      await _playNext();
    });

    _tts.setCancelHandler(() {
      state = TtsState.stopped;
      notifyListeners();
    });

    _tts.setErrorHandler((msg) {
      state = TtsState.stopped;
      notifyListeners();
      onError?.call(msg.toString());
    });

    // Load voices
    try {
      _availableVoices = await _tts.getVoices ?? [];
      notifyListeners();
    } catch (_) {}
  }

  // ---------------------------------------------------------------------------
  // Playback control
  // ---------------------------------------------------------------------------
  Future<void> play(List<String> sentences, {int startIdx = 0}) async {
    await stop();
    _sentences     = sentences;
    _currentIdx    = startIdx;
    _stopRequested = false;
    state = TtsState.playing;
    notifyListeners();
    await _applySettings();
    await _playNext();
  }

  Future<void> _playNext() async {
    if (_stopRequested) {
      state = TtsState.stopped;
      notifyListeners();
      return;
    }
    if (_currentIdx >= _sentences.length) {
      state = TtsState.stopped;
      notifyListeners();
      onPlaybackFinished?.call();
      return;
    }
    final sentence = _sentences[_currentIdx].trim();
    if (sentence.isEmpty) {
      _currentIdx++;
      await _playNext();
      return;
    }
    onSentenceStart?.call(_currentIdx);
    await _tts.speak(sentence);
  }

  Future<void> pause() async {
    if (state == TtsState.playing) {
      await _tts.pause();
      state = TtsState.paused;
      notifyListeners();
    }
  }

  Future<void> resume() async {
    if (state == TtsState.paused) {
      // flutter_tts doesn't support resume; restart from current sentence
      state = TtsState.playing;
      notifyListeners();
      await _applySettings();
      await _playNext();
    }
  }

  Future<void> stop() async {
    _stopRequested = true;
    await _tts.stop();
    state = TtsState.stopped;
    notifyListeners();
  }

  Future<void> skipToSentence(List<String> sentences, int idx) async {
    await stop();
    _sentences     = sentences;
    _currentIdx    = idx;
    _stopRequested = false;
    state = TtsState.playing;
    notifyListeners();
    await _applySettings();
    await _playNext();
  }

  Future<void> prevSentence(List<String> sentences) async {
    final prev = (_currentIdx - 1).clamp(0, sentences.length - 1);
    await skipToSentence(sentences, prev);
  }

  Future<void> nextSentence(List<String> sentences) async {
    final next = (_currentIdx + 1).clamp(0, sentences.length - 1);
    await skipToSentence(sentences, next);
  }

  // ---------------------------------------------------------------------------
  // Settings
  // ---------------------------------------------------------------------------
  Future<void> setSpeed(double s) async {
    speed = s.clamp(0.1, 1.5);
    // Android TTS speed range is effectively 0.3-0.9 for comfortable listening.
    // Map our 0.1-1.5 slider to 0.25-1.0 TTS range.
    final ttsRate = 0.25 + (speed - 0.1) * (0.75 / 1.4);
    await _tts.setSpeechRate(ttsRate);
    notifyListeners();
  }

  Future<void> setPitch(double p) async {
    pitch = p.clamp(0.5, 2.0);
    await _tts.setPitch(pitch);
    notifyListeners();
  }

  Future<void> setVolume(double v) async {
    volume = v.clamp(0.0, 1.0);
    await _tts.setVolume(volume);
    notifyListeners();
  }

  Future<void> setVoice(Map<String, String> voiceMap) async {
    voice = voiceMap['name'] ?? '';
    try {
      await _tts.setVoice(voiceMap);
      notifyListeners();
    } catch (_) {}
  }

  Future<void> previewVoice(Map<String, String> voiceMap) async {
    await stop();
    await _applySettings();
    try {
      await _tts.setVoice(voiceMap);
    } catch (_) {}
    await _tts.speak('Hello, this is a voice preview from Narrator of Death.');
  }

  Future<void> _applySettings() async {
    final ttsRate = 0.25 + (speed - 0.1) * (0.75 / 1.4);
    await _tts.setSpeechRate(ttsRate);
    await _tts.setPitch(pitch);
    await _tts.setVolume(volume);
  }

  int get currentSentenceIndex => _currentIdx;
  bool get isPlaying => state == TtsState.playing;
  bool get isPaused  => state == TtsState.paused;
  bool get isStopped => state == TtsState.stopped;

  @override
  void dispose() {
    _tts.stop();
    super.dispose();
  }
}
