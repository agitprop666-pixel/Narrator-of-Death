import 'package:flutter/material.dart';
import '../theme.dart';
import '../tts/tts_manager.dart';

class ControlsBar extends StatelessWidget {
  final TtsManager tts;
  final VoidCallback onPlay;
  final VoidCallback onPause;
  final VoidCallback onStop;
  final VoidCallback onPrevSentence;
  final VoidCallback onNextSentence;
  final VoidCallback onPrevChapter;
  final VoidCallback onNextChapter;
  final ValueChanged<double> onSpeedChanged;

  const ControlsBar({
    super.key,
    required this.tts,
    required this.onPlay,
    required this.onPause,
    required this.onStop,
    required this.onPrevSentence,
    required this.onNextSentence,
    required this.onPrevChapter,
    required this.onNextChapter,
    required this.onSpeedChanged,
  });

  Widget _ctrlBtn(IconData icon, VoidCallback onTap, {double size = 28}) =>
      InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(4),
        child: Padding(
          padding: const EdgeInsets.all(8),
          child: Icon(icon, color: kUiText, size: size),
        ),
      );

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: tts,
      builder: (context, _) {
        final isPlaying = tts.isPlaying;
        return Container(
          color: kUiBg2,
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Transport row
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _ctrlBtn(Icons.skip_previous, onPrevChapter),
                  _ctrlBtn(Icons.navigate_before, onPrevSentence),
                  // Play / Pause
                  InkWell(
                    onTap: isPlaying ? onPause : onPlay,
                    borderRadius: BorderRadius.circular(24),
                    child: Container(
                      width: 48,
                      height: 48,
                      decoration: const BoxDecoration(
                        color: kDarkRed,
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        isPlaying ? Icons.pause : Icons.play_arrow,
                        color: Colors.white,
                        size: 28,
                      ),
                    ),
                  ),
                  _ctrlBtn(Icons.stop, onStop),
                  _ctrlBtn(Icons.navigate_next, onNextSentence),
                  _ctrlBtn(Icons.skip_next, onNextChapter),
                ],
              ),
              // Speed row
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  children: [
                    const Text('Speed', style: TextStyle(color: kUiTextDim, fontSize: 12)),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Slider(
                        value: tts.speed,
                        min:   0.1,
                        max:   1.5,
                        divisions: 14,
                        label: '${tts.speed.toStringAsFixed(1)}x',
                        onChanged: onSpeedChanged,
                      ),
                    ),
                    Text(
                      '${tts.speed.toStringAsFixed(1)}x',
                      style: const TextStyle(color: kUiTextDim, fontSize: 12),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
