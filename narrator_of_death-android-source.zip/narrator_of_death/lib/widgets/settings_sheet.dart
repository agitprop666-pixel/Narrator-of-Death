import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../theme.dart';
import '../tts/tts_manager.dart';

class SettingsSheet extends StatefulWidget {
  final TtsManager tts;
  final double fontSize;
  final String fontFamily;
  final void Function(double size) onFontSizeChanged;
  final void Function(String family) onFontFamilyChanged;

  const SettingsSheet({
    super.key,
    required this.tts,
    required this.fontSize,
    required this.fontFamily,
    required this.onFontSizeChanged,
    required this.onFontFamilyChanged,
  });

  @override
  State<SettingsSheet> createState() => _SettingsSheetState();
}

class _SettingsSheetState extends State<SettingsSheet> {
  late double _fontSize;
  late String _fontFamily;
  Map<String, String>? _selectedVoice;

  static const _fontFamilies = ['Georgia', 'serif', 'Arial', 'monospace'];
  static const _fontLabels   = ['Georgia', 'Serif', 'Arial', 'Monospace'];

  @override
  void initState() {
    super.initState();
    _fontSize   = widget.fontSize;
    _fontFamily = widget.fontFamily;
  }

  List<Map<String, String>> get _voices {
    return widget.tts.availableVoices
        .whereType<Map>()
        .map((v) => v.cast<String, String>())
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      initialChildSize: 0.75,
      minChildSize: 0.4,
      maxChildSize: 0.95,
      expand: false,
      builder: (context, scrollCtrl) => Container(
        decoration: const BoxDecoration(
          color: kUiBg2,
          borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
        ),
        child: Column(
          children: [
            // Handle
            Container(
              margin: const EdgeInsets.symmetric(vertical: 8),
              width: 40, height: 4,
              decoration: BoxDecoration(
                color: kBorder,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            // Title
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(
                children: [
                  Icon(Icons.settings, color: kAccentRed),
                  SizedBox(width: 8),
                  Text('Settings',
                      style: TextStyle(
                          color: kUiText,
                          fontSize: 18,
                          fontWeight: FontWeight.bold)),
                ],
              ),
            ),
            const Divider(color: kBorder),
            Expanded(
              child: ListView(
                controller: scrollCtrl,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                children: [
                  // ---- TTS Section ----
                  _sectionHeader('Text-to-Speech'),

                  // Speed
                  _labelRow('Speed', '${widget.tts.speed.toStringAsFixed(1)}x'),
                  ListenableBuilder(
                    listenable: widget.tts,
                    builder: (_, __) => Slider(
                      value: widget.tts.speed,
                      min: 0.1, max: 1.5, divisions: 14,
                      onChanged: (v) => widget.tts.setSpeed(v),
                    ),
                  ),

                  // Pitch
                  _labelRow('Pitch', widget.tts.pitch.toStringAsFixed(1)),
                  ListenableBuilder(
                    listenable: widget.tts,
                    builder: (_, __) => Slider(
                      value: widget.tts.pitch,
                      min: 0.5, max: 2.0, divisions: 15,
                      onChanged: (v) => widget.tts.setPitch(v),
                    ),
                  ),

                  // Volume
                  _labelRow('Volume', '${(widget.tts.volume * 100).round()}%'),
                  ListenableBuilder(
                    listenable: widget.tts,
                    builder: (_, __) => Slider(
                      value: widget.tts.volume,
                      min: 0.0, max: 1.0, divisions: 20,
                      onChanged: (v) => widget.tts.setVolume(v),
                    ),
                  ),

                  // Voice selector
                  const SizedBox(height: 8),
                  const Text('Voice', style: TextStyle(color: kUiTextDim, fontSize: 13)),
                  const SizedBox(height: 4),
                  if (_voices.isEmpty)
                    const Text('No voices available',
                        style: TextStyle(color: kUiTextDim))
                  else
                    DropdownButtonFormField<Map<String, String>>(
                      value: _selectedVoice,
                      dropdownColor: kUiBg3,
                      style: const TextStyle(color: kUiText),
                      hint: const Text('Select voice',
                          style: TextStyle(color: kUiTextDim)),
                      items: _voices.map((v) {
                        final name   = v['name']   ?? '';
                        final locale = v['locale']  ?? v['language'] ?? '';
                        return DropdownMenuItem(
                          value: v,
                          child: Text('$name ($locale)',
                              style: const TextStyle(color: kUiText, fontSize: 13),
                              overflow: TextOverflow.ellipsis),
                        );
                      }).toList(),
                      onChanged: (v) {
                        if (v != null) {
                          setState(() => _selectedVoice = v);
                          widget.tts.setVoice(v);
                        }
                      },
                    ),

                  // Preview button
                  const SizedBox(height: 8),
                  ElevatedButton.icon(
                    icon: const Icon(Icons.volume_up, size: 18),
                    label: const Text('Preview Voice'),
                    onPressed: _selectedVoice != null
                        ? () => widget.tts.previewVoice(_selectedVoice!)
                        : null,
                  ),

                  const SizedBox(height: 16),
                  const Divider(color: kBorder),

                  // ---- Reader Section ----
                  _sectionHeader('Reader'),

                  // Font size
                  _labelRow('Font Size', _fontSize.round().toString()),
                  Slider(
                    value: _fontSize,
                    min: 10, max: 32, divisions: 22,
                    onChanged: (v) {
                      setState(() => _fontSize = v);
                      widget.onFontSizeChanged(v);
                    },
                  ),

                  // Font family
                  const SizedBox(height: 8),
                  const Text('Font', style: TextStyle(color: kUiTextDim, fontSize: 13)),
                  const SizedBox(height: 4),
                  DropdownButtonFormField<String>(
                    value: _fontFamily,
                    dropdownColor: kUiBg3,
                    style: const TextStyle(color: kUiText),
                    items: List.generate(_fontFamilies.length, (i) =>
                      DropdownMenuItem(
                        value: _fontFamilies[i],
                        child: Text(_fontLabels[i],
                            style: TextStyle(
                                fontFamily: _fontFamilies[i],
                                color: kUiText)),
                      ),
                    ),
                    onChanged: (v) {
                      if (v != null) {
                        setState(() => _fontFamily = v);
                        widget.onFontFamilyChanged(v);
                      }
                    },
                  ),
                  const SizedBox(height: 24),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sectionHeader(String text) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Text(text,
            style: const TextStyle(
                color: kAccentRed,
                fontSize: 13,
                fontWeight: FontWeight.bold,
                letterSpacing: 0.5)),
      );

  Widget _labelRow(String label, String value) => Padding(
        padding: const EdgeInsets.only(top: 8),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label, style: const TextStyle(color: kUiTextDim, fontSize: 13)),
            Text(value, style: const TextStyle(color: kUiText, fontSize: 13)),
          ],
        ),
      );
}
