import 'dart:io';
import 'package:flutter/material.dart';
import '../models.dart';
import '../theme.dart';

class BookCard extends StatelessWidget {
  final LibraryEntry entry;
  final bool gridMode;
  final VoidCallback onOpen;
  final VoidCallback onRemove;

  const BookCard({
    super.key,
    required this.entry,
    required this.gridMode,
    required this.onOpen,
    required this.onRemove,
  });

  @override
  Widget build(BuildContext context) {
    return gridMode ? _buildGrid(context) : _buildList(context);
  }

  Widget _buildGrid(BuildContext context) {
    return GestureDetector(
      onTap: onOpen,
      onLongPress: () => _showMenu(context),
      child: Container(
        decoration: BoxDecoration(
          color: kUiBg2,
          borderRadius: BorderRadius.circular(6),
          border: Border.all(color: kBorder),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Cover
            Expanded(
              child: ClipRRect(
                borderRadius:
                    const BorderRadius.vertical(top: Radius.circular(6)),
                child: _buildCover(boxFit: BoxFit.cover),
              ),
            ),
            // Title + author
            Padding(
              padding: const EdgeInsets.all(6),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    entry.title.isNotEmpty
                        ? entry.title
                        : _stem(entry.filePath),
                    style: const TextStyle(
                        color: kUiText,
                        fontSize: 11,
                        fontWeight: FontWeight.bold),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  if (entry.author.isNotEmpty)
                    Text(entry.author,
                        style: const TextStyle(
                            color: kUiTextDim, fontSize: 10),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildList(BuildContext context) {
    return ListTile(
      contentPadding:
          const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      leading: SizedBox(
        width: 40,
        height: 56,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(3),
          child: _buildCover(boxFit: BoxFit.cover),
        ),
      ),
      title: Text(
        entry.title.isNotEmpty ? entry.title : _stem(entry.filePath),
        style: const TextStyle(color: kUiText, fontWeight: FontWeight.bold),
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
      subtitle: Text(
        entry.author.isNotEmpty ? entry.author : 'Unknown Author',
        style: const TextStyle(color: kUiTextDim, fontSize: 12),
      ),
      trailing: PopupMenuButton<String>(
        color: kUiBg3,
        icon: const Icon(Icons.more_vert, color: kUiTextDim),
        onSelected: (v) {
          if (v == 'open') onOpen();
          if (v == 'remove') onRemove();
        },
        itemBuilder: (_) => [
          const PopupMenuItem(value: 'open',
              child: Text('Open', style: TextStyle(color: kUiText))),
          const PopupMenuItem(value: 'remove',
              child: Text('Remove', style: TextStyle(color: kAccentRed))),
        ],
      ),
      onTap: onOpen,
    );
  }

  Widget _buildCover({required BoxFit boxFit}) {
    // Try cached cover file
    if (entry.coverCachePath != null &&
        entry.coverCachePath!.isNotEmpty) {
      final f = File(entry.coverCachePath!);
      if (f.existsSync()) {
        return Image.file(f, fit: boxFit,
            errorBuilder: (_, __, ___) => _placeholder());
      }
    }
    return _placeholder();
  }

  Widget _placeholder() {
    return Container(
      color: const Color(0xFF141414),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.menu_book, color: kDarkRed, size: 32),
          const SizedBox(height: 4),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: Text(
              entry.title.isNotEmpty
                  ? entry.title
                  : _stem(entry.filePath),
              style: const TextStyle(
                  color: kAccentRed,
                  fontSize: 9,
                  fontWeight: FontWeight.bold),
              maxLines: 2,
              textAlign: TextAlign.center,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

  void _showMenu(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: kUiBg2,
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.open_in_new, color: kUiText),
              title: const Text('Open', style: TextStyle(color: kUiText)),
              onTap: () { Navigator.pop(context); onOpen(); },
            ),
            ListTile(
              leading: const Icon(Icons.delete, color: kAccentRed),
              title: const Text('Remove from Library',
                  style: TextStyle(color: kAccentRed)),
              onTap: () { Navigator.pop(context); onRemove(); },
            ),
          ],
        ),
      ),
    );
  }

  String _stem(String path) =>
      path.split('/').last.replaceAll(RegExp(r'\.[^.]+$'), '');
}
