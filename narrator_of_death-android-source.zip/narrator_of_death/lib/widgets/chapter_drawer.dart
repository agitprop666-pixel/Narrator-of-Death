import 'package:flutter/material.dart';
import '../models.dart';
import '../database.dart';
import '../theme.dart';

class ChapterDrawer extends StatefulWidget {
  final List<Chapter> chapters;
  final int currentChapterIndex;
  final String filePath;
  final void Function(int chapterIdx) onChapterSelected;
  final void Function(int chapterIdx, int sentenceIdx) onBookmarkSelected;

  const ChapterDrawer({
    super.key,
    required this.chapters,
    required this.currentChapterIndex,
    required this.filePath,
    required this.onChapterSelected,
    required this.onBookmarkSelected,
  });

  @override
  State<ChapterDrawer> createState() => _ChapterDrawerState();
}

class _ChapterDrawerState extends State<ChapterDrawer>
    with SingleTickerProviderStateMixin {
  late TabController _tabCtrl;
  List<Bookmark> _bookmarks = [];
  final _db = AppDatabase();

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 2, vsync: this);
    // Reload bookmarks whenever the bookmark tab is tapped
    _tabCtrl.addListener(() {
      if (_tabCtrl.index == 1) _loadBookmarks();
    });
    _loadBookmarks();
  }

  @override
  void didUpdateWidget(ChapterDrawer old) {
    super.didUpdateWidget(old);
    // Reload when drawer is reopened with new state
    _loadBookmarks();
  }

  Future<void> _loadBookmarks() async {
    final bms = await _db.getBookmarks(widget.filePath);
    if (mounted) setState(() => _bookmarks = bms);
  }

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: kUiBg2,
      child: SafeArea(
        child: Column(
          children: [
            // Header
            Container(
              color: kDarkRed,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: const Row(
                children: [
                  Icon(Icons.menu_book, color: Colors.white),
                  SizedBox(width: 8),
                  Text('Contents',
                      style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16)),
                ],
              ),
            ),
            // Tabs
            TabBar(
              controller: _tabCtrl,
              tabs: const [
                Tab(text: 'Chapters'),
                Tab(text: 'Bookmarks'),
              ],
            ),
            // Tab content
            Expanded(
              child: TabBarView(
                controller: _tabCtrl,
                children: [
                  _buildChapterList(),
                  _buildBookmarkList(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildChapterList() {
    if (widget.chapters.isEmpty) {
      return const Center(
          child: Text('No chapters', style: TextStyle(color: kUiTextDim)));
    }
    return ListView.builder(
      itemCount: widget.chapters.length,
      itemBuilder: (context, i) {
        final ch       = widget.chapters[i];
        final selected = i == widget.currentChapterIndex;
        return ListTile(
          selected:  selected,
          selectedColor: Colors.white,
          selectedTileColor: kDarkRed,
          leading: Text('${i + 1}',
              style: TextStyle(
                  color: selected ? Colors.white : kUiTextDim,
                  fontSize: 12)),
          title: Text(ch.title,
              style: TextStyle(
                  color: selected ? Colors.white : kUiText,
                  fontWeight: selected ? FontWeight.bold : FontWeight.normal,
                  fontSize: 14),
              maxLines: 2,
              overflow: TextOverflow.ellipsis),
          onTap: () {
            Navigator.pop(context);
            widget.onChapterSelected(i);
          },
        );
      },
    );
  }

  Widget _buildBookmarkList() {
    if (_bookmarks.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.bookmark_border, color: kUiTextDim, size: 48),
            const SizedBox(height: 8),
            const Text('No bookmarks yet', style: TextStyle(color: kUiTextDim)),
            const SizedBox(height: 4),
            const Text('Press the bookmark button\nwhile reading',
                style: TextStyle(color: kUiTextDim, fontSize: 12),
                textAlign: TextAlign.center),
          ],
        ),
      );
    }

    return ListView.builder(
      itemCount: _bookmarks.length,
      itemBuilder: (context, i) {
        final bm = _bookmarks[i];
        final chTitle = bm.chapterIndex < widget.chapters.length
            ? widget.chapters[bm.chapterIndex].title
            : 'Chapter ${bm.chapterIndex + 1}';
        final label = bm.label.isNotEmpty ? bm.label : 'Bookmark @ $chTitle';

        return ListTile(
          leading: const Icon(Icons.bookmark, color: kAccentRed, size: 20),
          title: Text(label,
              style: const TextStyle(color: kUiText, fontSize: 14),
              maxLines: 1,
              overflow: TextOverflow.ellipsis),
          subtitle: Text('$chTitle • sentence ${bm.sentenceIndex + 1}',
              style: const TextStyle(color: kUiTextDim, fontSize: 12)),
          trailing: PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert, color: kUiTextDim, size: 18),
            color: kUiBg3,
            onSelected: (action) async {
              if (action == 'edit') await _editBookmark(bm);
              if (action == 'delete') await _deleteBookmark(bm.id);
            },
            itemBuilder: (_) => [
              const PopupMenuItem(value: 'edit',
                  child: Text('Edit', style: TextStyle(color: kUiText))),
              const PopupMenuItem(value: 'delete',
                  child: Text('Delete', style: TextStyle(color: kAccentRed))),
            ],
          ),
          onTap: () {
            Navigator.pop(context);
            widget.onBookmarkSelected(bm.chapterIndex, bm.sentenceIndex);
          },
        );
      },
    );
  }

  Future<void> _editBookmark(Bookmark bm) async {
    final labelCtrl = TextEditingController(text: bm.label);
    final noteCtrl  = TextEditingController(text: bm.note);
    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: kUiBg2,
        title: const Text('Edit Bookmark', style: TextStyle(color: kUiText)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: labelCtrl,
                style: const TextStyle(color: kUiText),
                decoration: const InputDecoration(labelText: 'Label')),
            const SizedBox(height: 8),
            TextField(controller: noteCtrl,
                style: const TextStyle(color: kUiText),
                decoration: const InputDecoration(labelText: 'Note')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx),
              child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              await _db.updateBookmark(bm.id, labelCtrl.text, noteCtrl.text);
              if (mounted) Navigator.pop(ctx);
              await _loadBookmarks();
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  Future<void> _deleteBookmark(int id) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: kUiBg2,
        title: const Text('Delete Bookmark', style: TextStyle(color: kUiText)),
        content: const Text('Delete this bookmark?',
            style: TextStyle(color: kUiTextDim)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: kAccentRed),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (confirm == true) {
      await _db.deleteBookmark(id);
      await _loadBookmarks();
    }
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    super.dispose();
  }
}
