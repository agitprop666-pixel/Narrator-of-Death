import 'package:flutter/material.dart';
import '../theme.dart';

class ReaderPanel extends StatefulWidget {
  final List<String> sentences;
  final int highlightedIndex;
  final double fontSize;
  final String fontFamily;
  final void Function(int idx) onSentenceTap;

  const ReaderPanel({
    super.key,
    required this.sentences,
    required this.highlightedIndex,
    required this.fontSize,
    required this.fontFamily,
    required this.onSentenceTap,
  });

  @override
  State<ReaderPanel> createState() => _ReaderPanelState();
}

class _ReaderPanelState extends State<ReaderPanel> {
  final ScrollController _scroll = ScrollController();
  final List<GlobalKey> _keys    = [];

  @override
  void initState() {
    super.initState();
    _rebuildKeys();
  }

  @override
  void didUpdateWidget(ReaderPanel old) {
    super.didUpdateWidget(old);
    if (old.sentences.length != widget.sentences.length) {
      _rebuildKeys();
    }
    // Scroll to highlighted sentence when it changes
    if (old.highlightedIndex != widget.highlightedIndex &&
        widget.highlightedIndex >= 0) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _scrollTo(widget.highlightedIndex));
    }
  }

  void _rebuildKeys() {
    _keys.clear();
    for (int i = 0; i < widget.sentences.length; i++) {
      _keys.add(GlobalKey());
    }
  }

  void _scrollTo(int idx) {
    if (idx < 0 || idx >= _keys.length) return;
    final ctx = _keys[idx].currentContext;
    if (ctx == null) return;
    Scrollable.ensureVisible(
      ctx,
      alignment: 0.3,
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeInOut,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: kReaderBg,
      child: SingleChildScrollView(
        controller: _scroll,
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
        child: Wrap(
          children: List.generate(widget.sentences.length, (i) {
            final isHighlighted = i == widget.highlightedIndex;
            return GestureDetector(
              key: _keys[i],
              onTap: () => widget.onSentenceTap(i),
              child: Container(
                margin: const EdgeInsets.only(right: 4, bottom: 2),
                padding: isHighlighted
                    ? const EdgeInsets.symmetric(horizontal: 2, vertical: 1)
                    : EdgeInsets.zero,
                decoration: isHighlighted
                    ? BoxDecoration(
                        color: kHighlightBg,
                        borderRadius: BorderRadius.circular(2),
                      )
                    : null,
                child: Text(
                  '${widget.sentences[i]} ',
                  style: TextStyle(
                    fontFamily: widget.fontFamily,
                    fontSize:   widget.fontSize,
                    color: isHighlighted ? kHighlightFg : kReaderText,
                    fontWeight: isHighlighted
                        ? FontWeight.bold
                        : FontWeight.normal,
                    height: 1.7,
                  ),
                ),
              ),
            );
          }),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _scroll.dispose();
    super.dispose();
  }
}
