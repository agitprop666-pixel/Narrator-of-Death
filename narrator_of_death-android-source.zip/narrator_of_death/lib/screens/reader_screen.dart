import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models.dart';
import '../database.dart';
import '../theme.dart';
import '../tts/tts_manager.dart';
import '../widgets/reader_panel.dart';
import '../widgets/controls_bar.dart';
import '../widgets/chapter_drawer.dart';
import '../widgets/settings_sheet.dart';

class ReaderScreen extends StatefulWidget {
  final Book book;

  const ReaderScreen({super.key, required this.book});

  @override
  State<ReaderScreen> createState() => _ReaderScreenState();
}

class _ReaderScreenState extends State<ReaderScreen>
    with WidgetsBindingObserver {
  late TtsManager _tts;
  final _db = AppDatabase();

  final _scaffoldKey = GlobalKey<ScaffoldState>();
  int _chapterIdx   = 0;
  int _sentenceIdx  = 0;
  int _bookmarkCount = 0;

  double _fontSize   = 16.0;
  String _fontFamily = 'Georgia';

  bool _settingsOpen = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _tts = TtsManager();
    _tts.onSentenceStart  = _onSentenceStart;
    _tts.onSentenceFinish = _onSentenceFinish;
    _tts.onPlaybackFinished = _onPlaybackFinished;
    _tts.onError = (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('TTS error: $e'),
                backgroundColor: kAccentRed));
      }
    };
    _loadPrefs();
    _restorePosition();
  }

  Future<void> _loadPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _fontSize   = prefs.getDouble('font_size')   ?? 16.0;
      _fontFamily = prefs.getString('font_family') ?? 'Georgia';
    });
  }

  Future<void> _savePrefs() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('font_size',   _fontSize);
    await prefs.setString('font_family', _fontFamily);
  }

  Future<void> _restorePosition() async {
    final pos = await _db.getPosition(widget.book.filePath);
    setState(() {
      _chapterIdx  = pos.chapterIndex
          .clamp(0, (widget.book.chapters.length - 1).clamp(0, 9999));
      _sentenceIdx = pos.sentenceIndex;
    });
  }

  Future<void> _savePosition() async {
    await _db.savePosition(widget.book.filePath, _chapterIdx, _sentenceIdx);
  }

  // ---------------------------------------------------------------------------
  // TTS callbacks
  // ---------------------------------------------------------------------------
  void _onSentenceStart(int idx) {
    if (mounted) setState(() => _sentenceIdx = idx);
  }

  void _onSentenceFinish(int idx) {
    _savePosition();
  }

  void _onPlaybackFinished() {
    if (_chapterIdx < widget.book.chapters.length - 1) {
      setState(() {
        _chapterIdx++;
        _sentenceIdx = 0;
      });
      _play();
    } else {
      if (mounted) setState(() {});
    }
  }

  // ---------------------------------------------------------------------------
  // Playback
  // ---------------------------------------------------------------------------
  void _play() {
    if (widget.book.chapters.isEmpty) return;
    final ch = widget.book.chapters[_chapterIdx];
    _tts.play(ch.sentences, startIdx: _sentenceIdx);
  }

  void _pause() => _tts.pause();
  void _resume() => _tts.resume();

  void _stop() {
    _tts.stop();
    _savePosition();
  }

  void _prevSentence() {
    _stop();
    final sentences = widget.book.chapters[_chapterIdx].sentences;
    setState(() => _sentenceIdx = (_sentenceIdx - 1).clamp(0, sentences.length - 1));
  }

  void _nextSentence() {
    _stop();
    final sentences = widget.book.chapters[_chapterIdx].sentences;
    setState(() => _sentenceIdx = (_sentenceIdx + 1).clamp(0, sentences.length - 1));
  }

  void _prevChapter() {
    _stop();
    setState(() {
      _chapterIdx  = (_chapterIdx - 1).clamp(0, widget.book.chapters.length - 1);
      _sentenceIdx = 0;
    });
    _savePosition();
  }

  void _nextChapter() {
    _stop();
    setState(() {
      _chapterIdx  = (_chapterIdx + 1).clamp(0, widget.book.chapters.length - 1);
      _sentenceIdx = 0;
    });
    _savePosition();
  }

  void _onSentenceTap(int idx) {
    final wasPlaying = _tts.isPlaying;
    _stop();
    setState(() => _sentenceIdx = idx);
    if (wasPlaying) _play();
  }

  void _onChapterSelected(int idx) {
    _stop();
    setState(() { _chapterIdx = idx; _sentenceIdx = 0; });
    _savePosition();
  }

  void _onBookmarkSelected(int chIdx, int sentIdx) {
    _stop();
    setState(() { _chapterIdx = chIdx; _sentenceIdx = sentIdx; });
    _savePosition();
  }

  // ---------------------------------------------------------------------------
  // Bookmark
  // ---------------------------------------------------------------------------
  Future<void> _addBookmark() async {
    final labelCtrl = TextEditingController();
    final noteCtrl  = TextEditingController();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: kUiBg2,
        title: const Text('Add Bookmark', style: TextStyle(color: kUiText)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: labelCtrl,
              style: const TextStyle(color: kUiText),
              decoration: const InputDecoration(labelText: 'Label (optional)'),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: noteCtrl,
              style: const TextStyle(color: kUiText),
              decoration: const InputDecoration(labelText: 'Note (optional)'),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Add'),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      await _db.addBookmark(
        filePath:      widget.book.filePath,
        chapterIndex:  _chapterIdx,
        sentenceIndex: _sentenceIdx,
        label:         labelCtrl.text,
        note:          noteCtrl.text,
      );
      if (mounted) {
        setState(() => _bookmarkCount++);
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Bookmark added'),
                duration: Duration(seconds: 1)));
      }
    }
  }

  // ---------------------------------------------------------------------------
  // Build
  // ---------------------------------------------------------------------------
  @override
  Widget build(BuildContext context) {
    final chapters = widget.book.chapters;
    if (chapters.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: Text(widget.book.title)),
        body: const Center(
            child: Text('No readable content found.',
                style: TextStyle(color: kUiTextDim))),
      );
    }

    final chapter   = chapters[_chapterIdx];
    final sentences = chapter.sentences;

    return ChangeNotifierProvider.value(
      value: _tts,
      child: Scaffold(
        key: _scaffoldKey,
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            tooltip: 'Back to Library',
            onPressed: () {
              _stop();
              _savePosition();
              Navigator.pop(context);
            },
          ),
          title: Text(
            widget.book.title,
            style: const TextStyle(fontSize: 16),
            overflow: TextOverflow.ellipsis,
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.menu),
              tooltip: 'Chapters & Bookmarks',
              onPressed: () => _scaffoldKey.currentState?.openDrawer(),
            ),
            IconButton(
              icon: const Icon(Icons.bookmark_add),
              tooltip: 'Add Bookmark',
              onPressed: _addBookmark,
            ),
            IconButton(
              icon: const Icon(Icons.settings),
              tooltip: 'Settings',
              onPressed: () => _showSettings(),
            ),
          ],
        ),
        drawer: ChapterDrawer(
          key:                ValueKey(_bookmarkCount),
          chapters:           chapters,
          currentChapterIndex: _chapterIdx,
          filePath:           widget.book.filePath,
          onChapterSelected:  _onChapterSelected,
          onBookmarkSelected: _onBookmarkSelected,
        ),
        body: Column(
          children: [
            // Chapter title bar
            Container(
              width: double.infinity,
              color: kUiBg2,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
              child: Row(
                children: [
                  const Icon(Icons.menu_book, color: kUiTextDim, size: 14),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      '${_chapterIdx + 1} / ${chapters.length}  •  ${chapter.title}',
                      style: const TextStyle(
                          color: kUiTextDim, fontSize: 12),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
            // Reader
            Expanded(
              child: ReaderPanel(
                sentences:        sentences,
                highlightedIndex: _sentenceIdx,
                fontSize:         _fontSize,
                fontFamily:       _fontFamily,
                onSentenceTap:    _onSentenceTap,
              ),
            ),
            // Controls
            ControlsBar(
              tts:             _tts,
              onPlay:          _play,
              onPause:         _tts.isPaused ? _resume : _pause,
              onStop:          _stop,
              onPrevSentence:  _prevSentence,
              onNextSentence:  _nextSentence,
              onPrevChapter:   _prevChapter,
              onNextChapter:   _nextChapter,
              onSpeedChanged:  (v) => _tts.setSpeed(v),
            ),
          ],
        ),
      ),
    );
  }

  void _showSettings() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => SettingsSheet(
        tts:               _tts,
        fontSize:          _fontSize,
        fontFamily:        _fontFamily,
        onFontSizeChanged: (v) {
          setState(() => _fontSize = v);
          _savePrefs();
        },
        onFontFamilyChanged: (v) {
          setState(() => _fontFamily = v);
          _savePrefs();
        },
      ),
    );
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.detached) {
      _tts.stop();
      _savePosition();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _tts.stop();
    _savePosition();
    _tts.dispose();
    super.dispose();
  }
}
