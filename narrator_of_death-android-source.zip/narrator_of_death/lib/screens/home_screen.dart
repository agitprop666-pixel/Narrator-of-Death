import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;
import 'package:shared_preferences/shared_preferences.dart';

import '../models.dart';
import '../database.dart';
import '../theme.dart';
import '../widgets/book_card.dart';
import '../parsers/epub_parser.dart';
import '../parsers/pdf_parser.dart';
import '../parsers/txt_parser.dart';
import '../parsers/docx_parser.dart';
import 'reader_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _db = AppDatabase();
  static const _channel = MethodChannel('com.example.narrator_of_death/file_picker');

  List<LibraryEntry> _library = [];
  bool _loading = false;
  bool _gridMode = true;

  @override
  void initState() {
    super.initState();
    _loadPrefs();
    _refreshLibrary();
  }

  Future<void> _loadPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() => _gridMode = prefs.getBool('shelf_grid') ?? true);
  }

  Future<void> _refreshLibrary() async {
    final entries = await _db.getLibrary();
    if (mounted) setState(() => _library = entries);
  }

  Future<void> _openFilePicker() async {
    try {
      final String? path = await _channel.invokeMethod('pickFile');
      if (path == null || path.isEmpty) return;
      await _loadBook(path);
    } on PlatformException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('File picker error: ${e.message}'),
                backgroundColor: kAccentRed));
      }
    }
  }

  Future<void> _loadBook(String filePath) async {
    if (!mounted) return;
    setState(() => _loading = true);
    try {
      final book = await _parseBook(filePath);
      String coverPath = '';
      if (book.coverBytes != null) {
        coverPath = await _saveCover(book.fileHash, book.coverBytes!);
      }
      await _db.upsertLibrary(
        filePath:   filePath,
        title:      book.title,
        author:     book.author,
        coverCache: coverPath,
        fileHash:   book.fileHash,
      );
      await _refreshLibrary();
      if (mounted) {
        Navigator.push(context,
            MaterialPageRoute(builder: (_) => ReaderScreen(book: book)));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Could not open file: $e'),
                backgroundColor: kAccentRed));
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<Book> _parseBook(String filePath) async {
    final ext = p.extension(filePath).toLowerCase();
    switch (ext) {
      case '.epub': return EpubParser().parse(filePath);
      case '.pdf':  return PdfParser().parse(filePath);
      case '.docx': return DocxParser().parse(filePath);
      default:      return TxtParser().parse(filePath);
    }
  }

  Future<String> _saveCover(String hash, Uint8List bytes) async {
    try {
      final dir    = await getApplicationDocumentsDirectory();
      final covers = Directory(p.join(dir.path, 'covers'));
      await covers.create(recursive: true);
      final file   = File(p.join(covers.path, '$hash.png'));
      await file.writeAsBytes(bytes);
      return file.path;
    } catch (_) {
      return '';
    }
  }

  Future<void> _openLibraryEntry(LibraryEntry entry) async {
    final file = File(entry.filePath);
    if (!await file.exists()) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('File not found on device.'),
                backgroundColor: kAccentRed));
      }
      return;
    }
    await _loadBook(entry.filePath);
  }

  Future<void> _removeBook(LibraryEntry entry) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: kUiBg2,
        title: const Text('Remove Book', style: TextStyle(color: kUiText)),
        content: const Text('Remove from library?\nThe file will not be deleted.',
            style: TextStyle(color: kUiTextDim)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: kAccentRed),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Remove'),
          ),
        ],
      ),
    );
    if (confirm == true) {
      await _db.removeFromLibrary(entry.filePath);
      await _refreshLibrary();
    }
  }

  void _toggleView() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() => _gridMode = !_gridMode);
    await prefs.setBool('shelf_grid', _gridMode);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Narrator of Death'),
        actions: [
          IconButton(
            icon: Icon(_gridMode ? Icons.view_list : Icons.grid_view),
            tooltip: _gridMode ? 'List view' : 'Grid view',
            onPressed: _toggleView,
          ),
          IconButton(
            icon: const Icon(Icons.folder_open),
            tooltip: 'Open file',
            onPressed: _loading ? null : _openFilePicker,
          ),
        ],
      ),
      body: _loading
          ? const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(color: kAccentRed),
                  SizedBox(height: 16),
                  Text('Loading book...', style: TextStyle(color: kUiTextDim)),
                ],
              ),
            )
          : _library.isEmpty
              ? _buildEmpty()
              : _gridMode
                  ? _buildGrid()
                  : _buildList(),
      floatingActionButton: FloatingActionButton(
        backgroundColor: kDarkRed,
        foregroundColor: Colors.white,
        onPressed: _loading ? null : _openFilePicker,
        tooltip: 'Open book',
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildEmpty() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.menu_book, color: kDarkRed, size: 80),
          const SizedBox(height: 16),
          const Text('No books yet',
              style: TextStyle(color: kUiText, fontSize: 20,
                  fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('Tap + to open a book',
              style: TextStyle(color: kUiTextDim)),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            icon: const Icon(Icons.folder_open),
            label: const Text('Open Book'),
            onPressed: _openFilePicker,
          ),
        ],
      ),
    );
  }

  Widget _buildGrid() {
    return GridView.builder(
      padding: const EdgeInsets.all(12),
      gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
        maxCrossAxisExtent: 180,
        childAspectRatio: 0.6,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
      ),
      itemCount: _library.length,
      itemBuilder: (_, i) => BookCard(
        entry:    _library[i],
        gridMode: true,
        onOpen:   () => _openLibraryEntry(_library[i]),
        onRemove: () => _removeBook(_library[i]),
      ),
    );
  }

  Widget _buildList() {
    return ListView.separated(
      padding: const EdgeInsets.all(8),
      itemCount: _library.length,
      separatorBuilder: (_, __) => const Divider(color: kBorder, height: 1),
      itemBuilder: (_, i) => BookCard(
        entry:    _library[i],
        gridMode: false,
        onOpen:   () => _openLibraryEntry(_library[i]),
        onRemove: () => _removeBook(_library[i]),
      ),
    );
  }
}
