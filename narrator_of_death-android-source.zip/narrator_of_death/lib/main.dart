import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'theme.dart';
import 'screens/home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Allow both portrait and landscape
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
    DeviceOrientation.landscapeLeft,
    DeviceOrientation.landscapeRight,
  ]);

  // Dark status bar + navigation bar to match theme
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor:          Colors.transparent,
    statusBarIconBrightness: Brightness.light,
  ));

  runApp(const NarratorOfDeathApp());
}

class NarratorOfDeathApp extends StatelessWidget {
  const NarratorOfDeathApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title:         'Narrator of Death',
      theme:         buildAppTheme(),
      debugShowCheckedModeBanner: false,
      home:          const HomeScreen(),
    );
  }
}
