import 'package:flutter/material.dart';

// ---------------------------------------------------------------------------
// Colour palette
// ---------------------------------------------------------------------------
const Color kUiBg        = Color(0xFF1E1E1E);
const Color kUiBg2       = Color(0xFF2D2D2D);
const Color kUiBg3       = Color(0xFF3A3A3A);
const Color kDarkRed     = Color(0xFF8B0000);
const Color kAccentRed   = Color(0xFFC41E3A);
const Color kUiText      = Color(0xFFE8E8E8);
const Color kUiTextDim   = Color(0xFFAAAAAA);
const Color kBorder      = Color(0xFF444444);
const Color kReaderBg    = Color(0xFFFFFFF0);
const Color kReaderText  = Color(0xFF1A1A1A);
const Color kHighlightBg = Color(0xFFFFD700);
const Color kHighlightFg = Color(0xFF000000);

const String kAppFont = 'Arial';

// ---------------------------------------------------------------------------
// App theme
// ---------------------------------------------------------------------------
ThemeData buildAppTheme() {
  return ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: kUiBg,
    colorScheme: const ColorScheme.dark(
      primary:   kDarkRed,
      secondary: kAccentRed,
      surface:   kUiBg2,
      onPrimary: Colors.white,
      onSurface: kUiText,
    ),
    fontFamily: kAppFont,
    appBarTheme: const AppBarTheme(
      backgroundColor: kDarkRed,
      foregroundColor: Colors.white,
      titleTextStyle: TextStyle(
        fontFamily: kAppFont,
        fontSize: 18,
        fontWeight: FontWeight.bold,
        color: Colors.white,
      ),
      iconTheme: IconThemeData(color: Colors.white),
      elevation: 2,
    ),
    drawerTheme: const DrawerThemeData(
      backgroundColor: kUiBg2,
    ),
    listTileTheme: const ListTileThemeData(
      textColor: kUiText,
      iconColor: kUiTextDim,
    ),
    textTheme: const TextTheme(
      bodyLarge:  TextStyle(color: kUiText, fontFamily: kAppFont),
      bodyMedium: TextStyle(color: kUiText, fontFamily: kAppFont),
      bodySmall:  TextStyle(color: kUiTextDim, fontFamily: kAppFont),
      titleLarge: TextStyle(color: kUiText, fontFamily: kAppFont, fontWeight: FontWeight.bold),
    ),
    tabBarTheme: const TabBarThemeData(
      labelColor:        Colors.white,
      unselectedLabelColor: kUiTextDim,
      indicator: UnderlineTabIndicator(
        borderSide: BorderSide(color: kAccentRed, width: 2),
      ),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: kUiBg3,
        foregroundColor: kUiText,
        side: const BorderSide(color: kBorder),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
      ),
    ),
    sliderTheme: const SliderThemeData(
      activeTrackColor:   kAccentRed,
      inactiveTrackColor: kUiBg3,
      thumbColor:         kAccentRed,
      overlayColor:       Color(0x33C41E3A),
    ),
    dividerColor: kBorder,
    cardColor: kUiBg2,
    iconTheme: const IconThemeData(color: kUiTextDim),
    checkboxTheme: CheckboxThemeData(
      fillColor: WidgetStateProperty.resolveWith(
        (s) => s.contains(WidgetState.selected) ? kAccentRed : kUiBg3,
      ),
    ),
    inputDecorationTheme: const InputDecorationTheme(
      filled: true,
      fillColor: kUiBg2,
      border: OutlineInputBorder(),
      enabledBorder: OutlineInputBorder(
        borderSide: BorderSide(color: kBorder),
      ),
      focusedBorder: OutlineInputBorder(
        borderSide: BorderSide(color: kAccentRed),
      ),
      labelStyle: TextStyle(color: kUiTextDim),
      hintStyle:  TextStyle(color: kUiTextDim),
    ),
  );
}
