import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;
import 'dart:io';
import 'models.dart';

// Use filename as stable key — cache path changes each session
String stableKey(String filePath) => p.basename(filePath);

class AppDatabase {
  static AppDatabase? _instance;
  static Database? _db;

  AppDatabase._();
  factory AppDatabase() => _instance ??= AppDatabase._();

  Future<Database> get db async {
    _db ??= await _open();
    return _db!;
  }

  Future<Database> _open() async {
    final dbPath = p.join(await getDatabasesPath(), 'narrator.db');
    return openDatabase(
      dbPath,
      version: 1,
      onCreate: (db, version) async {
        await db.executeBatch([
          '''CREATE TABLE IF NOT EXISTS library (
              id          INTEGER PRIMARY KEY AUTOINCREMENT,
              file_path   TEXT UNIQUE NOT NULL,
              title       TEXT,
              author      TEXT,
              cover_cache TEXT,
              file_hash   TEXT,
              date_added  TEXT DEFAULT (datetime('now')),
              last_opened TEXT
          )''',
          '''CREATE TABLE IF NOT EXISTS positions (
              file_path      TEXT PRIMARY KEY,
              chapter_index  INTEGER DEFAULT 0,
              sentence_index INTEGER DEFAULT 0,
              updated        TEXT DEFAULT (datetime('now'))
          )''',
          '''CREATE TABLE IF NOT EXISTS bookmarks (
              id             INTEGER PRIMARY KEY AUTOINCREMENT,
              file_path      TEXT NOT NULL,
              chapter_index  INTEGER NOT NULL,
              sentence_index INTEGER NOT NULL,
              label          TEXT DEFAULT '',
              note           TEXT DEFAULT '',
              created        TEXT DEFAULT (datetime('now'))
          )''',
        ]);
      },
    );
  }

  // ---------------------------------------------------------------------------
  // Library
  // ---------------------------------------------------------------------------
  Future<void> upsertLibrary({
    required String filePath,
    required String title,
    required String author,
    String coverCache = '',
    String fileHash = '',
  }) async {
    final d = await db;
    await d.rawInsert('''
      INSERT INTO library (file_path, title, author, cover_cache, file_hash, last_opened)
      VALUES (?, ?, ?, ?, ?, datetime('now'))
      ON CONFLICT(file_path) DO UPDATE SET
        title=excluded.title, author=excluded.author,
        cover_cache=excluded.cover_cache, file_hash=excluded.file_hash,
        last_opened=datetime('now')
    ''', [filePath, title, author, coverCache, fileHash]);
  }

  Future<List<LibraryEntry>> getLibrary() async {
    final d = await db;
    final rows = await d.query('library', orderBy: 'last_opened DESC');
    return rows.map(LibraryEntry.fromMap).toList();
  }

  Future<void> removeFromLibrary(String filePath) async {
    final d = await db;
    await d.delete('library',   where: 'file_path = ?', whereArgs: [filePath]);
    await d.delete('positions', where: 'file_path = ?', whereArgs: [filePath]);
    await d.delete('bookmarks', where: 'file_path = ?', whereArgs: [filePath]);
  }

  // ---------------------------------------------------------------------------
  // Positions
  // ---------------------------------------------------------------------------
  Future<void> savePosition(String filePath, int chapter, int sentence) async {
    final d = await db;
    final key = stableKey(filePath);
    await d.rawInsert('''
      INSERT INTO positions (file_path, chapter_index, sentence_index, updated)
      VALUES (?, ?, ?, datetime('now'))
      ON CONFLICT(file_path) DO UPDATE SET
        chapter_index=excluded.chapter_index,
        sentence_index=excluded.sentence_index,
        updated=datetime('now')
    ''', [key, chapter, sentence]);
  }

  Future<ReadPosition> getPosition(String filePath) async {
    final d = await db;
    final key = stableKey(filePath);
    final rows = await d.query(
      'positions',
      where: 'file_path = ?',
      whereArgs: [key],
    );
    if (rows.isEmpty) {
      return ReadPosition(filePath: filePath, chapterIndex: 0, sentenceIndex: 0);
    }
    return ReadPosition(
      filePath:      filePath,
      chapterIndex:  rows.first['chapter_index'] as int,
      sentenceIndex: rows.first['sentence_index'] as int,
    );
  }

  // ---------------------------------------------------------------------------
  // Bookmarks
  // ---------------------------------------------------------------------------
  Future<int> addBookmark({
    required String filePath,
    required int chapterIndex,
    required int sentenceIndex,
    String label = '',
    String note  = '',
  }) async {
    final d = await db;
    final key = stableKey(filePath);
    return d.insert('bookmarks', {
      'file_path':      key,
      'chapter_index':  chapterIndex,
      'sentence_index': sentenceIndex,
      'label':          label,
      'note':           note,
    });
  }

  Future<List<Bookmark>> getBookmarks(String filePath) async {
    final d = await db;
    final key = stableKey(filePath);
    final rows = await d.query(
      'bookmarks',
      where: 'file_path = ?',
      whereArgs: [key],
      orderBy: 'chapter_index ASC, sentence_index ASC',
    );
    return rows.map(Bookmark.fromMap).toList();
  }

  Future<void> updateBookmark(int id, String label, String note) async {
    final d = await db;
    await d.update(
      'bookmarks',
      {'label': label, 'note': note},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<void> deleteBookmark(int id) async {
    final d = await db;
    await d.delete('bookmarks', where: 'id = ?', whereArgs: [id]);
  }

  Future<void> close() async => _db?.close();
}

// Extension for batch execution
extension _BatchExt on Database {
  Future<void> executeBatch(List<String> sqls) async {
    final batch = this.batch();
    for (final sql in sqls) {
      batch.execute(sql);
    }
    await batch.commit(noResult: true);
  }
}
