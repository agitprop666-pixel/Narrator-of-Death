import 'dart:typed_data';

// ---------------------------------------------------------------------------
// Chapter
// ---------------------------------------------------------------------------
class Chapter {
  final int index;
  final String title;
  final List<String> sentences;
  final String rawText;

  const Chapter({
    required this.index,
    required this.title,
    required this.sentences,
    required this.rawText,
  });
}

// ---------------------------------------------------------------------------
// Book
// ---------------------------------------------------------------------------
class Book {
  final String filePath;
  final String title;
  final String author;
  final List<Chapter> chapters;
  final Uint8List? coverBytes;   // raw image bytes for cover art
  final String fileHash;

  const Book({
    required this.filePath,
    required this.title,
    required this.author,
    required this.chapters,
    this.coverBytes,
    required this.fileHash,
  });

  int get totalSentences =>
      chapters.fold(0, (sum, ch) => sum + ch.sentences.length);
}

// ---------------------------------------------------------------------------
// LibraryEntry — lightweight row from DB for shelf display
// ---------------------------------------------------------------------------
class LibraryEntry {
  final int id;
  final String filePath;
  final String title;
  final String author;
  final String? coverCachePath;
  final String fileHash;
  final String lastOpened;

  const LibraryEntry({
    required this.id,
    required this.filePath,
    required this.title,
    required this.author,
    this.coverCachePath,
    required this.fileHash,
    required this.lastOpened,
  });

  factory LibraryEntry.fromMap(Map<String, dynamic> m) => LibraryEntry(
        id:             m['id'] as int,
        filePath:       m['file_path'] as String,
        title:          m['title'] as String? ?? '',
        author:         m['author'] as String? ?? '',
        coverCachePath: m['cover_cache'] as String?,
        fileHash:       m['file_hash'] as String? ?? '',
        lastOpened:     m['last_opened'] as String? ?? '',
      );
}

// ---------------------------------------------------------------------------
// ReadPosition
// ---------------------------------------------------------------------------
class ReadPosition {
  final String filePath;
  final int chapterIndex;
  final int sentenceIndex;

  const ReadPosition({
    required this.filePath,
    required this.chapterIndex,
    required this.sentenceIndex,
  });
}

// ---------------------------------------------------------------------------
// Bookmark
// ---------------------------------------------------------------------------
class Bookmark {
  final int id;
  final String filePath;
  final int chapterIndex;
  final int sentenceIndex;
  final String label;
  final String note;
  final String created;

  const Bookmark({
    required this.id,
    required this.filePath,
    required this.chapterIndex,
    required this.sentenceIndex,
    required this.label,
    required this.note,
    required this.created,
  });

  factory Bookmark.fromMap(Map<String, dynamic> m) => Bookmark(
        id:             m['id'] as int,
        filePath:       m['file_path'] as String,
        chapterIndex:   m['chapter_index'] as int,
        sentenceIndex:  m['sentence_index'] as int,
        label:          m['label'] as String? ?? '',
        note:           m['note'] as String? ?? '',
        created:        m['created'] as String? ?? '',
      );
}

// ---------------------------------------------------------------------------
// Sentence tokenizer (pure Dart)
// ---------------------------------------------------------------------------
List<String> tokenizeSentences(String text) {
  // Normalize whitespace
  text = text.replaceAll(RegExp(r'\s+'), ' ').trim();
  if (text.isEmpty) return [];

  // Split on sentence-ending punctuation followed by space + capital
  final parts = text.split(RegExp(r'(?<=[.!?])\s+(?=[A-Z])'));
  final result = <String>[];
  for (final p in parts) {
    final trimmed = p.trim();
    if (trimmed.isNotEmpty) result.add(trimmed);
  }
  return result.isEmpty ? [text] : result;
}

// ---------------------------------------------------------------------------
// Text cleaner
// ---------------------------------------------------------------------------
String cleanText(String text) {
  text = text.replaceAll(RegExp(r'\s+'), ' ');
  text = text.replaceAll(RegExp(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]'), '');
  return text.trim();
}
