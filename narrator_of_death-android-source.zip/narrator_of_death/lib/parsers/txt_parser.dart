import 'dart:io';
import '../models.dart';

class TxtParser {
  Future<Book> parse(String filePath) async {
    final raw = await File(filePath).readAsString();
    final title = _stem(filePath);

    // Split on triple newlines as section breaks
    final parts = raw.split(RegExp(r'\n{3,}'));
    final chapters = <Chapter>[];

    for (final part in parts) {
      final cleaned = cleanText(part);
      if (cleaned.length < 30) continue;
      chapters.add(Chapter(
        index:     chapters.length,
        title:     'Section ${chapters.length + 1}',
        sentences: tokenizeSentences(cleaned),
        rawText:   cleaned,
      ));
    }

    // If no section breaks found, treat whole file as one chapter
    if (chapters.isEmpty && raw.trim().isNotEmpty) {
      final cleaned = cleanText(raw);
      chapters.add(Chapter(
        index:     0,
        title:     title,
        sentences: tokenizeSentences(cleaned),
        rawText:   cleaned,
      ));
    }

    return Book(
      filePath: filePath,
      title:    title,
      author:   'Unknown',
      chapters: chapters,
      fileHash: _hash(filePath),
    );
  }

  String _stem(String path) =>
      path.split('/').last.replaceAll(RegExp(r'\.[^.]+$'), '');

  String _hash(String path) {
    try {
      final f = File(path);
      return '${f.lengthSync()}_${path.hashCode.abs()}';
    } catch (_) {
      return path.hashCode.abs().toString();
    }
  }
}
