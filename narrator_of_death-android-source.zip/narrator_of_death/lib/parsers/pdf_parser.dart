import 'dart:io';
import 'package:syncfusion_flutter_pdf/pdf.dart';
import '../models.dart';

class PdfParser {
  Future<Book> parse(String filePath) async {
    final bytes = await File(filePath).readAsBytes();
    final doc   = PdfDocument(inputBytes: bytes);

    String title  = _stem(filePath);
    String author = 'Unknown';

    // Metadata
    try {
      title  = doc.documentInformation.title.isNotEmpty
               ? doc.documentInformation.title : title;
      author = doc.documentInformation.author.isNotEmpty
               ? doc.documentInformation.author : author;
    } catch (_) {}

    final totalPages = doc.pages.count;
    final chapters   = <Chapter>[];
    const chunkSize  = 20;

    for (int start = 0; start < totalPages; start += chunkSize) {
      final end = (start + chunkSize).clamp(0, totalPages);
      final buf = StringBuffer();

      for (int pi = start; pi < end; pi++) {
        try {
          final extractor = PdfTextExtractor(doc);
          final text = extractor.extractText(startPageIndex: pi, endPageIndex: pi);
          buf.write(text);
          buf.write(' ');
        } catch (_) {}
      }

      final raw = cleanText(buf.toString());
      if (raw.length < 30) continue;

      chapters.add(Chapter(
        index:     chapters.length,
        title:     'Pages ${start + 1}-$end',
        sentences: tokenizeSentences(raw),
        rawText:   raw,
      ));
    }

    doc.dispose();

    return Book(
      filePath: filePath,
      title:    title,
      author:   author,
      chapters: chapters,
      fileHash: _hash(filePath),
    );
  }

  String _stem(String path) =>
      path.split('/').last.replaceAll(RegExp(r'\.[^.]+$'), '');

  String _hash(String path) {
    try {
      final f = File(path);
      return '${f.lengthSync()}_${path.hashCode.abs()}';
    } catch (_) {
      return path.hashCode.abs().toString();
    }
  }
}
