import 'dart:io';
import 'dart:typed_data';
import 'package:epubx/epubx.dart';
import 'package:image/image.dart' as img;
import 'package:html/parser.dart' as html_parser;
import '../models.dart';

class EpubParser {
  Future<Book> parse(String filePath) async {
    final bytes = await File(filePath).readAsBytes();
    final epub  = await EpubReader.readBook(bytes);

    final title  = epub.Title  ?? _stem(filePath);
    final author = epub.Author ?? 'Unknown';

    // Cover image — epubx v4 CoverImage is an Image object from the image package
    Uint8List? coverBytes;
    try {
      final cover = epub.CoverImage;
      if (cover != null) {
        // Encode Image object to PNG bytes
        coverBytes = Uint8List.fromList(img.encodePng(cover));
      }
    } catch (_) {
      // If cover extraction fails, try first image in content
      try {
        final images = epub.Content?.Images;
        if (images != null && images.isNotEmpty) {
          final firstImg = images.values.first;
          final content  = firstImg.Content;
          if (content != null) {
            if (content is Uint8List) {
              coverBytes = content;
            } else if (content is List<int>) {
              coverBytes = Uint8List.fromList(content);
            }
          }
        }
      } catch (_) {}
    }

    // Chapters via spine order (Content.Html)
    final chapters = <Chapter>[];

    try {
      final htmlItems = epub.Content?.Html;
      if (htmlItems != null && htmlItems.isNotEmpty) {
        int ci = 0;
        for (final item in htmlItems.values) {
          final content = item.Content;
          if (content == null) continue;
          final raw = _htmlToText(content);
          if (raw.length < 30) continue;
          chapters.add(Chapter(
            index:     ci,
            title:     'Chapter ${ci + 1}',
            sentences: tokenizeSentences(raw),
            rawText:   raw,
          ));
          ci++;
        }
      }
    } catch (_) {}

    // Fallback: use chapter refs
    if (chapters.isEmpty) {
      try {
        final refs = epub.Chapters;
        if (refs != null) {
          for (final ref in refs) {
            _flattenChapter(ref, chapters);
          }
        }
      } catch (_) {}
    }

    return Book(
      filePath:   filePath,
      title:      title,
      author:     author,
      chapters:   chapters,
      coverBytes: coverBytes,
      fileHash:   _hash(filePath),
    );
  }

  void _flattenChapter(EpubChapter chapter, List<Chapter> out) {
    final content = chapter.HtmlContent ?? '';
    final raw = _htmlToText(content);
    if (raw.length >= 30) {
      out.add(Chapter(
        index:     out.length,
        title:     chapter.Title ?? 'Chapter ${out.length + 1}',
        sentences: tokenizeSentences(raw),
        rawText:   raw,
      ));
    }
    final subs = chapter.SubChapters;
    if (subs != null) {
      for (final sub in subs) {
        _flattenChapter(sub, out);
      }
    }
  }

  String _htmlToText(String html) {
    if (html.isEmpty) return '';
    try {
      final doc = html_parser.parse(html);
      return cleanText(doc.body?.text ?? '');
    } catch (_) {
      return cleanText(html.replaceAll(RegExp(r'<[^>]+>'), ' '));
    }
  }

  String _stem(String path) =>
      path.split('/').last.replaceAll(RegExp(r'\.[^.]+$'), '');

  String _hash(String path) {
    try {
      final f = File(path);
      return '${f.lengthSync()}_${path.hashCode.abs()}';
    } catch (_) {
      return path.hashCode.abs().toString();
    }
  }
}
