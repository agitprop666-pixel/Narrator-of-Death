import 'dart:io';
import 'package:archive/archive_io.dart';
import 'package:xml/xml.dart';
import '../models.dart';

class DocxParser {
  Future<Book> parse(String filePath) async {
    final bytes  = await File(filePath).readAsBytes();
    final archive = ZipDecoder().decodeBytes(bytes);

    String title  = _stem(filePath);
    String author = 'Unknown';

    // Extract core properties (title, author)
    final coreFile = archive.findFile('docProps/core.xml');
    if (coreFile != null) {
      try {
        final xml = XmlDocument.parse(
            String.fromCharCodes(coreFile.content as List<int>));
        final titleEl  = xml.findAllElements('dc:title').firstOrNull;
        final authorEl = xml.findAllElements('dc:creator').firstOrNull;
        if (titleEl  != null && titleEl.innerText.isNotEmpty)  title  = titleEl.innerText;
        if (authorEl != null && authorEl.innerText.isNotEmpty) author = authorEl.innerText;
      } catch (_) {}
    }

    // Extract document.xml
    final docFile = archive.findFile('word/document.xml');
    if (docFile == null) {
      return Book(
        filePath: filePath, title: title, author: author,
        chapters: [], fileHash: _hash(filePath),
      );
    }

    final xmlStr = String.fromCharCodes(docFile.content as List<int>);
    final doc    = XmlDocument.parse(xmlStr);

    final chapters      = <Chapter>[];
    String currentTitle = 'Chapter 1';
    final currentParas  = <String>[];

    void flush() {
      final raw = cleanText(currentParas.join(' '));
      if (raw.length > 30) {
        chapters.add(Chapter(
          index:     chapters.length,
          title:     currentTitle,
          sentences: tokenizeSentences(raw),
          rawText:   raw,
        ));
      }
    }

    // Walk all paragraph elements
    for (final para in doc.findAllElements('w:p')) {
      // Detect heading style
      String styleName = '';
      try {
        final pStyle = para
            .findAllElements('w:pStyle')
            .firstOrNull;
        styleName = pStyle?.getAttribute('w:val') ?? '';
      } catch (_) {}

      final isHeading = styleName.toLowerCase().contains('heading') ||
                        RegExp(r'^[Hh]eading\d*$').hasMatch(styleName) ||
                        RegExp(r'^[Hh]\d$').hasMatch(styleName);

      // Extract all text runs from paragraph
      final runs = para.findAllElements('w:t');
      final paraText = runs.map((r) => r.innerText).join('').trim();

      if (isHeading) {
        if (currentParas.isNotEmpty) {
          flush();
          currentParas.clear();
        }
        currentTitle = paraText.isNotEmpty ? paraText : currentTitle;
      } else if (paraText.isNotEmpty) {
        currentParas.add(paraText);
      }
    }

    if (currentParas.isNotEmpty) flush();

    return Book(
      filePath: filePath,
      title:    title,
      author:   author,
      chapters: chapters,
      fileHash: _hash(filePath),
    );
  }

  String _stem(String path) =>
      path.split('/').last.replaceAll(RegExp(r'\.[^.]+$'), '');

  String _hash(String path) {
    try {
      final f = File(path);
      return '${f.lengthSync()}_${path.hashCode.abs()}';
    } catch (_) {
      return path.hashCode.abs().toString();
    }
  }
}
